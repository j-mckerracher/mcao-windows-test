$ErrorActionPreference = 'Continue'
$RunId = '20261103-r9'
if ($RunId -notmatch '^[A-Za-z0-9][A-Za-z0-9-]*$') { throw 'set $RunId to the RUN_ID of the Current request block' }
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Clone = Join-Path $Root 'src'
$Target = Join-Path $Root 'target'
$Results = Join-Path $Root $RunId
$RowsTsv = Join-Path $Results 'rows.tsv'
New-Item -ItemType Directory -Force -Path (Join-Path $Results 'logs') | Out-Null
$env:CARGO_TARGET_DIR = $Target
$shell = (Get-Process -Id $PID).Path

function Invoke-Row {
  param([string]$Id, [string]$Command, [int]$MinTests = 1, [scriptblock]$Action)
  $log = Join-Path (Join-Path $Results 'logs') "$Id.log"
  $start = Get-Date
  $lines = @(& $Action 2>&1 | ForEach-Object { "$_" })
  $code = $LASTEXITCODE
  $lines | Out-File -FilePath $log -Encoding utf8
  $secs = [int]((Get-Date) - $start).TotalSeconds
  $ran = @($lines | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
  $vacuous = ($MinTests -gt 0) -and ($ran -eq 0)
  "$Id`t$code`t$secs`tbinaries-with-tests=$ran`tvacuous=$vacuous`t$Command" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  "$Id exit=$code duration=${secs}s binaries-with-tests=$ran vacuous=$vacuous"
}

"r9 shell: $shell"
"targeted run: W-01 plus ROWS W-21; NOTES 'rerun W-21' opens the W-49/W-50/W-58 gate"

# ---------- W-01 (always part of a targeted run) ----------
Invoke-Row -Id 'W-01' -MinTests 0 -Command 'rustup show active-toolchain; rustc -V; cargo -V; rustc -Vv (inside the test checkout)' -Action {
  Push-Location -LiteralPath $Clone
  rustup show active-toolchain
  rustc -V
  cargo -V
  rustc -Vv
  Pop-Location
}

# ---------- W-21 ----------
Invoke-Row -Id 'W-21' -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test interrupt
  Pop-Location
}

# ---------- W-49 (section 4.8 loop, verbatim shape) ----------
$packetNotes = @(Get-Content -LiteralPath (Join-Path $Clone 'docs\windows-native-verification.md') -ErrorAction Stop | Where-Object { $_ -cmatch '^NOTES: ' })
$RerunRequested = ($packetNotes.Count -gt 0) -and ($packetNotes[0] -ceq 'NOTES: rerun W-21')
$summary = Join-Path $Results 'W-49-summary.txt'
if (-not $RerunRequested) {
  'W-49 SKIPPED: reason not requested'
} else {
  $rerunLog = Join-Path $Results 'logs\W-49-rerun.txt'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $rerunLog) | Out-Null
  "W-49 log file: $rerunLog" | Add-Content -LiteralPath $summary -Encoding utf8
  $rerunArgs = @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', 'escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait', '--', '--exact')
  $rerunCommand = 'cargo test -p mcao-backend-windows --locked --test interrupt escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait -- --exact'
  $rowBudgetMs = 1800000
  $runLimitMs = 600000
  $passes = 0
  $failures = 0
  $rowTimedOut = $false
  $rowStart = Get-Date
  for ($run = 1; $run -le 20; $run++) {
    $spentMs = [int]((Get-Date) - $rowStart).TotalMilliseconds
    $limitMs = [Math]::Min($runLimitMs, $rowBudgetMs - $spentMs)
    if ($limitMs -le 0) { $rowTimedOut = $true; break }
    $outFile = Join-Path $Results "W-49-run$run.out"
    $errFile = Join-Path $Results "W-49-run$run.err"
    $runStart = Get-Date
    $proc = Start-Process -FilePath 'cargo' -ArgumentList $rerunArgs -WorkingDirectory $Clone -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
    $finished = $proc.WaitForExit($limitMs)
    if (-not $finished) {
      & taskkill.exe /PID $proc.Id /T /F | Out-Null
      [void]$proc.WaitForExit(10000)
    }
    $secs = [int]((Get-Date) - $runStart).TotalSeconds
    $out = @()
    foreach ($file in $outFile, $errFile) {
      if (Test-Path -LiteralPath $file) {
        $out += @(Get-Content -LiteralPath $file)
        Remove-Item -LiteralPath $file
      }
    }
    $code = if ($finished) { $proc.ExitCode } else { 'TIMEOUT' }
    $ran = @($out | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
    if ($finished -and $code -eq 0) { $passes++ } else { $failures++ }
    "run=$run exit=$code" | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Where-Object { $_ -match 'panicked at|left:|right:|test result' } | ForEach-Object { "run=$run $_" } | Add-Content -LiteralPath $summary -Encoding utf8
    if (-not $finished) { "run=$run TIMEOUT: killed with its process tree at $limitMs ms" | Add-Content -LiteralPath $summary -Encoding utf8 }
    "W-49-run$run`t$code`t$secs`tbinaries-with-tests=$ran`tvacuous=$($ran -eq 0)`t$rerunCommand" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
    if (-not $finished -and $limitMs -lt $runLimitMs) { $rowTimedOut = $true; break }
  }
  if ($rowTimedOut) {
    "row TIMEOUT: the 30-minute row budget ended the loop at run $run" | Add-Content -LiteralPath $summary -Encoding utf8
    "W-49-row`tTIMEOUT`t`tbinaries-with-tests=0`tvacuous=n/a`trow stopped at its 30-minute budget at run $run" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  }
  "passes=$passes failures=$failures" | Add-Content -LiteralPath $summary -Encoding utf8
  "W-49: passes=$passes failures=$failures"
}

# ---------- W-50 (three whole-binary runs) ----------
if (-not $RerunRequested) {
  'W-50 SKIPPED: reason not requested'
} else {
  foreach ($run in 1..3) {
    Invoke-Row -Id "W-50-run$run" -MinTests 1 -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
      Push-Location -LiteralPath $Clone
      cargo test -p mcao-backend-windows --locked --test interrupt
      Pop-Location
    }
  }
}

# ---------- W-58 (section 4.9 corrected block with child-session-shell, verbatim) ----------
Invoke-Row -Id 'W-58' -MinTests 0 -Command 'escalation test launched five ways in one session (diagnostic; only with NOTES: rerun W-21)' -Action {
  $w58Notes = @(Get-Content -LiteralPath (Join-Path $Clone 'docs\windows-native-verification.md') -ErrorAction Stop | Where-Object { $_ -cmatch '^NOTES: ' })
  if (-not (($w58Notes.Count -gt 0) -and ($w58Notes[0] -ceq 'NOTES: rerun W-21'))) {
    'W-58 SKIPPED: reason not requested'
    $global:LASTEXITCODE = 0
    return
  }
  $env:CARGO_TARGET_DIR = $Target
  $shell = (Get-Process -Id $PID).Path
  $ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $rowBudgetMs = 1800000
  $runLimitMs = 120000
  $rowStart = Get-Date
  $rowTimedOut = $false
  "psHost=$($Host.Name) shell=$($PSVersionTable.PSVersion) stdinRedirected=$([Console]::IsInputRedirected) stdoutRedirected=$([Console]::IsOutputRedirected)"
  $ancestor = (Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$PID" -ErrorAction SilentlyContinue).ParentProcessId
  for ($depth = 1; $depth -le 5; $depth++) {
    if (-not $ancestor) { break }
    $proc = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$ancestor" -ErrorAction SilentlyContinue
    if (-not $proc) { break }
    "ancestor$depth=$($proc.Name) pid=$($proc.ProcessId)"
    $ancestor = $proc.ParentProcessId
  }
  $w58Test = 'escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait'
  $w58Args = @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', $w58Test, '--', '--exact')
  $w58Line = "cargo test -p mcao-backend-windows --locked --test interrupt $w58Test -- --exact"
  # Build once, bounded by the row budget, so the timed runs do not include compilation. Its exit code is recorded.
  $buildOut = Join-Path $Results 'W-58-build.out'
  $buildErr = Join-Path $Results 'W-58-build.err'
  $buildLimitMs = $rowBudgetMs - [int]((Get-Date) - $rowStart).TotalMilliseconds
  $build = Start-Process -FilePath 'cargo' -ArgumentList @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', '--no-run') -WorkingDirectory $Clone -NoNewWindow -PassThru -RedirectStandardOutput $buildOut -RedirectStandardError $buildErr
  if ($build.WaitForExit($buildLimitMs)) {
    $buildCode = $build.ExitCode
  } else {
    & taskkill.exe /PID $build.Id /T /F | Out-Null
    [void]$build.WaitForExit(10000)
    $buildCode = 'TIMEOUT'
  }
  $buildText = @()
  foreach ($file in $buildOut, $buildErr) {
    if (Test-Path -LiteralPath $file) {
      $buildText += @(Get-Content -LiteralPath $file)
      Remove-Item -LiteralPath $file
    }
  }
  $buildText
  "build exit=$buildCode"
  if ("$buildCode" -ne '0') {
    'build failed: the five variants were not run; last 30 lines of build output follow'
    $buildText | Select-Object -Last 30
    $global:LASTEXITCODE = $buildCode
    return
  }
  foreach ($variant in 'direct-start-process', 'child-session-shell', 'child-powershell51', 'cmd-c', 'new-console-window') {
    for ($run = 1; $run -le 3; $run++) {
      $outFile = Join-Path $Results "W-58-$variant-$run.out"
      $errFile = Join-Path $Results "W-58-$variant-$run.err"
      $spentMs = [int]((Get-Date) - $rowStart).TotalMilliseconds
      $limitMs = [Math]::Min($runLimitMs, $rowBudgetMs - $spentMs)
      if ($limitMs -le 0) {
        $rowTimedOut = $true
        "variant=$variant run=$run exit=TIMEOUT: row budget ended before this run"
        continue
      }
      $startArgs = @{ WorkingDirectory = $Clone; PassThru = $true }
      switch ($variant) {
        'direct-start-process' { $startArgs += @{ FilePath = 'cargo'; ArgumentList = $w58Args; NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'child-session-shell' { $startArgs += @{ FilePath = $shell; ArgumentList = @('-NoProfile', '-Command', "& cargo $($w58Args -join ' '); exit `$LASTEXITCODE"); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'child-powershell51' { $startArgs += @{ FilePath = $ps51; ArgumentList = @('-NoProfile', '-Command', "$w58Line; exit `$LASTEXITCODE"); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'cmd-c' { $startArgs += @{ FilePath = $env:ComSpec; ArgumentList = @('/c', $w58Line); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'new-console-window' { $startArgs += @{ FilePath = $env:ComSpec; ArgumentList = @('/c', "$w58Line > `"$outFile`" 2>&1") } }
      }
      $started = Start-Process @startArgs
      if ($started.WaitForExit($limitMs)) {
        $code = $started.ExitCode
      } else {
        & taskkill.exe /PID $started.Id /T /F | Out-Null
        [void]$started.WaitForExit(10000)
        $code = 'TIMEOUT'
        if ($limitMs -lt $runLimitMs) { $rowTimedOut = $true }
      }
      $text = @()
      foreach ($file in $outFile, $errFile) {
        if (Test-Path -LiteralPath $file) {
          $text += @(Get-Content -LiteralPath $file)
          Remove-Item -LiteralPath $file
        }
      }
      "variant=$variant run=$run exit=$code"
      $text
      $hits = @($text | Where-Object { $_ -match 'panicked at|left:|right:|both reach the stub|test result|^running' })
      "variant=$variant run=$run filtered: $($hits -join ' | ')"
      if ("$code" -ne '0') {
        "variant=$variant run=$run last 30 lines:"
        $text | Select-Object -Last 30
      }
    }
  }
  if ($rowTimedOut) {
    'W-58 row TIMEOUT: the 30-minute row budget ended the loop; runs marked TIMEOUT above did not complete'
    $global:LASTEXITCODE = 'TIMEOUT'
    return
  }
  $global:LASTEXITCODE = 0
}

# ---------- close ----------
$closeLines = @()
Push-Location -LiteralPath $Clone
$closeLines += 'git status --porcelain after last row:'
$closeLines += @(git status --porcelain)
Pop-Location
$closeLines += "clone clean: $($closeLines.Count -eq 1)"
$closeLines | Out-File -FilePath (Join-Path $Results 'logs\close.log') -Encoding utf8
$closeLines
'R9-DONE'

