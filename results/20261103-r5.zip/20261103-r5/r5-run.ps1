. (Join-Path $PSScriptRoot 'r5-common.ps1')
"r5 shell: $shell"
"targeted run: W-01 plus ROWS W-21,W-58; NOTES 'rerun W-21' opens the W-49/W-50/W-58 gate"

# ---------- W-01 (always part of a targeted run) ----------
Invoke-Row -Id 'W-01' -MinTests 0 -Command 'rustup show active-toolchain; rustc -V; cargo -V; rustc -Vv (inside the test checkout)' -Action {
  Push-Location -LiteralPath $Clone
  rustup show active-toolchain
  rustc -V
  cargo -V
  rustc -Vv
  Pop-Location
}

# ---------- W-21 ----------
Invoke-Row -Id 'W-21' -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test interrupt
  Pop-Location
}

# ---------- W-49 (section 4.8 loop, verbatim shape) ----------
$packetNotes = @(Get-Content -LiteralPath (Join-Path $Clone 'docs\windows-native-verification.md') -ErrorAction Stop | Where-Object { $_ -cmatch '^NOTES: ' })
$RerunRequested = ($packetNotes.Count -gt 0) -and ($packetNotes[0] -ceq 'NOTES: rerun W-21')
$summary = Join-Path $Results 'W-49-summary.txt'
if (-not $RerunRequested) {
  'W-49 SKIPPED: reason not requested'
} else {
  $rerunLog = Join-Path $Results 'logs\W-49-rerun.txt'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $rerunLog) | Out-Null
  "W-49 log file: $rerunLog" | Add-Content -LiteralPath $summary -Encoding utf8
  $rerunArgs = @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', 'escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait', '--', '--exact')
  $rerunCommand = 'cargo test -p mcao-backend-windows --locked --test interrupt escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait -- --exact'
  $rowBudgetMs = 1800000
  $runLimitMs = 600000
  $passes = 0
  $failures = 0
  $rowTimedOut = $false
  $rowStart = Get-Date
  for ($run = 1; $run -le 20; $run++) {
    $spentMs = [int]((Get-Date) - $rowStart).TotalMilliseconds
    $limitMs = [Math]::Min($runLimitMs, $rowBudgetMs - $spentMs)
    if ($limitMs -le 0) { $rowTimedOut = $true; break }
    $outFile = Join-Path $Results "W-49-run$run.out"
    $errFile = Join-Path $Results "W-49-run$run.err"
    $runStart = Get-Date
    $proc = Start-Process -FilePath 'cargo' -ArgumentList $rerunArgs -WorkingDirectory $Clone -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
    $finished = $proc.WaitForExit($limitMs)
    if (-not $finished) {
      & taskkill.exe /PID $proc.Id /T /F | Out-Null
      [void]$proc.WaitForExit(10000)
    }
    $secs = [int]((Get-Date) - $runStart).TotalSeconds
    $out = @()
    foreach ($file in $outFile, $errFile) {
      if (Test-Path -LiteralPath $file) {
        $out += @(Get-Content -LiteralPath $file)
        Remove-Item -LiteralPath $file
      }
    }
    $code = if ($finished) { $proc.ExitCode } else { 'TIMEOUT' }
    $ran = @($out | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
    if ($finished -and $code -eq 0) { $passes++ } else { $failures++ }
    "run=$run exit=$code" | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Where-Object { $_ -match 'panicked at|left:|right:|test result' } | ForEach-Object { "run=$run $_" } | Add-Content -LiteralPath $summary -Encoding utf8
    if (-not $finished) { "run=$run TIMEOUT: killed with its process tree at $limitMs ms" | Add-Content -LiteralPath $summary -Encoding utf8 }
    "W-49-run$run`t$code`t$secs`tbinaries-with-tests=$ran`tvacuous=$($ran -eq 0)`t$rerunCommand" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
    if (-not $finished -and $limitMs -lt $runLimitMs) { $rowTimedOut = $true; break }
  }
  if ($rowTimedOut) {
    "row TIMEOUT: the 30-minute row budget ended the loop at run $run" | Add-Content -LiteralPath $summary -Encoding utf8
    "W-49-row`tTIMEOUT`t`tbinaries-with-tests=0`tvacuous=n/a`trow stopped at its 30-minute budget at run $run" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  }
  "passes=$passes failures=$failures" | Add-Content -LiteralPath $summary -Encoding utf8
  "W-49: passes=$passes failures=$failures"
}

# ---------- W-50 (section 4.8, three whole-binary runs) ----------
if (-not $RerunRequested) {
  'W-50 SKIPPED: reason not requested'
} else {
  foreach ($run in 1..3) {
    Invoke-Row -Id "W-50-run$run" -MinTests 1 -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
      Push-Location -LiteralPath $Clone
      cargo test -p mcao-backend-windows --locked --test interrupt
      Pop-Location
    }
  }
}

# ---------- W-58 (section 4.9 launch matrix, verbatim) ----------
Invoke-Row -Id 'W-58' -MinTests 0 -Command 'escalation test launched five ways in one session (diagnostic; only with NOTES: rerun W-21)' -Action {
  $w58Notes = @(Get-Content -LiteralPath (Join-Path $Clone 'docs\windows-native-verification.md') -ErrorAction Stop | Where-Object { $_ -cmatch '^NOTES: ' })
  if (-not (($w58Notes.Count -gt 0) -and ($w58Notes[0] -ceq 'NOTES: rerun W-21'))) {
    'W-58 SKIPPED: reason not requested'
    $global:LASTEXITCODE = 0
    return
  }
  $env:CARGO_TARGET_DIR = $Target
  "host=$($Host.Name) shell=$($PSVersionTable.PSVersion) stdinRedirected=$([Console]::IsInputRedirected) stdoutRedirected=$([Console]::IsOutputRedirected)"
  $ancestor = $PID
  for ($depth = 0; $depth -lt 6; $depth++) {
    $proc = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$ancestor" -ErrorAction SilentlyContinue
    if (-not $proc) { break }
    "ancestor$depth=$($proc.Name) pid=$($proc.ProcessId)"
    $ancestor = $proc.ParentProcessId
  }
  $w58Test = 'escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait'
  $w58Args = @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', $w58Test, '--', '--exact')
  $w58Line = "cargo test -p mcao-backend-windows --locked --test interrupt $w58Test -- --exact"
  # Build once so the timed runs do not include compilation.
  Push-Location -LiteralPath $Clone
  & cargo test -p mcao-backend-windows --locked --test interrupt --no-run 2>&1 | Select-Object -Last 2
  Pop-Location
  $ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  foreach ($variant in 'direct-start-process', 'in-process', 'child-powershell51', 'cmd-c', 'new-console-window') {
    for ($run = 1; $run -le 3; $run++) {
      $outFile = Join-Path $Results "W-58-$variant-$run.out"
      $errFile = Join-Path $Results "W-58-$variant-$run.err"
      $code = 'n/a'
      if ($variant -eq 'in-process') {
        Push-Location -LiteralPath $Clone
        & cargo @w58Args *> $outFile
        $code = $LASTEXITCODE
        Pop-Location
      } else {
        $startArgs = @{ WorkingDirectory = $Clone; PassThru = $true }
        switch ($variant) {
          'direct-start-process' { $startArgs += @{ FilePath = 'cargo'; ArgumentList = $w58Args; NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
          'child-powershell51' { $startArgs += @{ FilePath = $ps51; ArgumentList = @('-NoProfile', '-Command', $w58Line); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
          'cmd-c' { $startArgs += @{ FilePath = $env:ComSpec; ArgumentList = @('/c', $w58Line); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
          'new-console-window' { $startArgs += @{ FilePath = $env:ComSpec; ArgumentList = @('/c', "$w58Line > `"$outFile`" 2>&1") } }
        }
        $started = Start-Process @startArgs
        if ($started.WaitForExit(120000)) {
          $code = $started.ExitCode
        } else {
          & taskkill.exe /PID $started.Id /T /F | Out-Null
          [void]$started.WaitForExit(10000)
          $code = 'TIMEOUT'
        }
      }
      $text = @()
      foreach ($file in $outFile, $errFile) {
        if (Test-Path -LiteralPath $file) {
          $text += @(Get-Content -LiteralPath $file)
          Remove-Item -LiteralPath $file
        }
      }
      $detail = @($text | Where-Object { $_ -match 'panicked at|both reach the stub|test result' }) -join ' | '
      "variant=$variant run=$run exit=$code $detail"
    }
  }
  $global:LASTEXITCODE = 0
}

# ---------- close ----------
$closeLines = @()
Push-Location -LiteralPath $Clone
$closeLines += 'git status --porcelain after last row:'
$closeLines += @(git status --porcelain)
Pop-Location
$closeLines += "clone clean: $($closeLines.Count -eq 1)"
$closeLines | Out-File -FilePath (Join-Path $Results 'logs\close.log') -Encoding utf8
$closeLines
'R5-DONE'

