
param([hashtable]$p)
& (Get-Process -Id $PID).Path -NoProfile -ExecutionPolicy Bypass -File ([string]$p['Script']) `
  -Mcao ([string]$p['Mcao']) -PathValue ([string]$p['PathValue']) -FmHome ([string]$p['FmHome']) `
  -OneDriveVar ([string]$p['OneDriveVar']) -OneDriveValue ([string]$p['OneDriveValue']) `
  -UserProfile ([string]$p['UserProfile'])
exit $LASTEXITCODE
