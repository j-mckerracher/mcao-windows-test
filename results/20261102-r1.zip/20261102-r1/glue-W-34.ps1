$shell = (Get-Process -Id $PID).Path
& $shell -NoProfile -ExecutionPolicy Bypass -File 'C:\Users\<user>\AppData\Local\mcao-winverify\20261102-r1\preflight-child.ps1' -Mcao 'C:\Users\<user>\AppData\Local\mcao-winverify\target\debug\mcao.exe' -PathValue 'C:\WINDOWS\System32' -FmHome '' -OneDriveVar '' -OneDriveValue '' -UserProfile '' -ExpectGitMissing
exit $LASTEXITCODE
