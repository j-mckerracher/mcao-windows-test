param([string]$ProbeExe, [string]$OutDir)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$forbidden = 'bash.exe', 'sh.exe', 'wsl.exe'
$found = [System.Collections.Generic.SortedSet[string]]::new()
$kept = @()
$removed = 0
foreach ($dir in ($env:Path -split ';' | Where-Object { $_ })) {
  $hits = @($forbidden | Where-Object { Test-Path -LiteralPath (Join-Path $dir $_) })
  $unixlike = $dir -match '(?i)[\\/](msys64|msys2|cygwin|cygwin64)([\\/]|$)'
  if ($hits.Count -gt 0 -or $unixlike) {
    $removed++
    foreach ($hit in $hits) { [void]$found.Add($hit) }
  } else {
    $kept += $dir
  }
}
$env:Path = $kept -join ';'
$missing = [ordered]@{}
foreach ($name in 'bash', 'sh', 'wsl') {
  $missing[$name] = $null -eq (Get-Command $name -ErrorAction SilentlyContinue)
}
$proof = [ordered]@{
  removed_directories     = $removed
  kept_directories        = $kept.Count
  forbidden_found_on_path = @($found)
  command_missing_after   = $missing
}
$proof | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 (Join-Path $OutDir 'bash-free-path.json')
if ($missing.Values -contains $false) { throw 'a forbidden shell is still on PATH' }
$evidence = Join-Path $OutDir 'probe-evidence.json'
& $ProbeExe --backend native --harness stub --scenario cooperative --evidence-out $evidence
if ($LASTEXITCODE -ne 0) { throw "mcao-probe exited $LASTEXITCODE" }
$expected = [ordered]@{
  spawn       = 'demonstrated'
  capture     = 'unsupported'
  send_text   = 'unsupported'
  interrupt   = 'unsupported'
  agent_state = 'demonstrated'
  reconnect   = 'unsupported'
  cleanup     = 'demonstrated'
}
$records = @(Get-Content -Raw $evidence | ConvertFrom-Json)
if ($records.Count -ne $expected.Count) { throw "expected $($expected.Count) records, got $($records.Count)" }
$i = 0
foreach ($name in $expected.Keys) {
  $record = $records[$i++]
  if ($record.operation -ne $name -or $record.support -ne $expected[$name]) {
    throw "operation $($record.operation): support $($record.support), expected $name $($expected[$name])"
  }
  if ($record.execution -ne 'native' -or $record.harness -ne 'stub' -or $record.backend -ne 'windows-job') {
    throw "operation $($record.operation) is not native windows-job stub evidence"
  }
}
Write-Output 'probe expectations matched'
