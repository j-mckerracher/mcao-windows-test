$ErrorActionPreference = 'Stop'
$RunId = '20261103-r6'
if ($RunId -notmatch '^[A-Za-z0-9][A-Za-z0-9-]*$') { throw 'bad RunId' }
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Results = Join-Path $Root $RunId
$Push = Join-Path $Root 'push'

# section 8 redaction over every text file in the run folder
$oneDriveRoots = @($env:OneDrive, $env:OneDriveCommercial, $env:OneDriveConsumer) | Where-Object { $_ }
Get-ChildItem -LiteralPath $Results -Recurse -File | Where-Object { $_.Extension -in '.log', '.md', '.txt', '.tsv', '.json', '.ps1' } | ForEach-Object {
  $text = Get-Content -LiteralPath $_.FullName -Raw
  foreach ($oneDriveRoot in $oneDriveRoots) {
    $text = $text -replace [regex]::Escape($oneDriveRoot), '<onedrive>'
    $text = $text -replace [regex]::Escape($oneDriveRoot.Replace('\', '\\')), '<onedrive>'
  }
  $text = $text -replace [regex]::Escape($env:USERNAME), '<user>'
  $text = $text -replace [regex]::Escape($env:COMPUTERNAME), '<host>'
  Set-Content -LiteralPath $_.FullName -Value $text -Encoding utf8
}
'redaction done'

# section 7 zip
$zip = Join-Path $Root "$RunId.zip"
Compress-Archive -LiteralPath $Results -DestinationPath $zip -Force
"zip size: $((Get-Item -LiteralPath $zip).Length)"

# copy into the results checkout, LATEST last
Copy-Item -LiteralPath $zip -Destination (Join-Path $Push "results\$RunId.zip") -Force
Copy-Item -LiteralPath (Join-Path $Results "$RunId-SUMMARY.md") -Destination (Join-Path $Push "results\$RunId-SUMMARY.md") -Force
Set-Content -LiteralPath (Join-Path $Push 'results\LATEST') -Value $RunId -Encoding ascii

# section 2.6 publish with retries
git -C $Push add -- results
$staged = @(git -C $Push diff --cached --name-only)
if ($staged.Count -eq 0) { throw 'nothing staged under results/' }
if (@($staged | Where-Object { $_ -notlike 'results/*' }).Count -gt 0) { throw 'staged path outside results/; stop' }
git -C $Push commit -m "results: $RunId"
if ($LASTEXITCODE -ne 0) { throw 'commit failed' }
$pushed = $false
for ($attempt = 1; $attempt -le 3; $attempt++) {
  git -C $Push pull --rebase
  if ($LASTEXITCODE -eq 0) {
    git -C $Push push origin windows-verification
    if ($LASTEXITCODE -eq 0) { $pushed = $true; break }
  }
}
if (-not $pushed) { throw 'push refused after three attempts; stop and report the error without credentials' }
"published commit: $(git -C $Push rev-parse HEAD)"
'STAGE-H-DONE'

