. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-f2 shell: $shell"
"NOTES is exactly 'rerun W-21': the W-49 and W-50 gate is open"

# ---------- W-49 (section 4.8 loop, verbatim shape) ----------
$packetNotes = @(Get-Content -LiteralPath (Join-Path $Clone 'docs\windows-native-verification.md') -ErrorAction Stop | Where-Object { $_ -cmatch '^NOTES: ' })
$RerunRequested = ($packetNotes.Count -gt 0) -and ($packetNotes[0] -ceq 'NOTES: rerun W-21')
$summary = Join-Path $Results 'W-49-summary.txt'
if (-not $RerunRequested) {
  'W-49 SKIPPED: reason not requested'
} else {
  $rerunLog = Join-Path $Results 'logs\W-49-rerun.txt'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $rerunLog) | Out-Null
  "W-49 log file: $rerunLog" | Add-Content -LiteralPath $summary -Encoding utf8
  $rerunArgs = @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', 'escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait', '--', '--exact')
  $rerunCommand = 'cargo test -p mcao-backend-windows --locked --test interrupt escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait -- --exact'
  $rowBudgetMs = 1800000
  $runLimitMs = 600000
  $passes = 0
  $failures = 0
  $rowTimedOut = $false
  $rowStart = Get-Date
  for ($run = 1; $run -le 20; $run++) {
    $spentMs = [int]((Get-Date) - $rowStart).TotalMilliseconds
    $limitMs = [Math]::Min($runLimitMs, $rowBudgetMs - $spentMs)
    if ($limitMs -le 0) { $rowTimedOut = $true; break }
    $outFile = Join-Path $Results "W-49-run$run.out"
    $errFile = Join-Path $Results "W-49-run$run.err"
    $runStart = Get-Date
    $proc = Start-Process -FilePath 'cargo' -ArgumentList $rerunArgs -WorkingDirectory $Clone -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
    $finished = $proc.WaitForExit($limitMs)
    if (-not $finished) {
      & taskkill.exe /PID $proc.Id /T /F | Out-Null
      [void]$proc.WaitForExit(10000)
    }
    $secs = [int]((Get-Date) - $runStart).TotalSeconds
    $out = @()
    foreach ($file in $outFile, $errFile) {
      if (Test-Path -LiteralPath $file) {
        $out += @(Get-Content -LiteralPath $file)
        Remove-Item -LiteralPath $file
      }
    }
    $code = if ($finished) { $proc.ExitCode } else { 'TIMEOUT' }
    $ran = @($out | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
    if ($finished -and $code -eq 0) { $passes++ } else { $failures++ }
    "run=$run exit=$code" | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Where-Object { $_ -match 'panicked at|left:|right:|test result' } | ForEach-Object { "run=$run $_" } | Add-Content -LiteralPath $summary -Encoding utf8
    if (-not $finished) { "run=$run TIMEOUT: killed with its process tree at $limitMs ms" | Add-Content -LiteralPath $summary -Encoding utf8 }
    "W-49-run$run`t$code`t$secs`tbinaries-with-tests=$ran`tvacuous=$($ran -eq 0)`t$rerunCommand" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
    if (-not $finished -and $limitMs -lt $runLimitMs) { $rowTimedOut = $true; break }
  }
  if ($rowTimedOut) {
    "row TIMEOUT: the 30-minute row budget ended the loop at run $run" | Add-Content -LiteralPath $summary -Encoding utf8
    "W-49-row`tTIMEOUT`t`tbinaries-with-tests=0`tvacuous=n/a`trow stopped at its 30-minute budget at run $run" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  }
  "passes=$passes failures=$failures" | Add-Content -LiteralPath $summary -Encoding utf8
  "W-49: passes=$passes failures=$failures"
}

# ---------- W-50 (section 4.8, three whole-binary runs) ----------
if (-not $RerunRequested) {
  'W-50 SKIPPED: reason not requested'
} else {
  foreach ($run in 1..3) {
    Invoke-Row -Id "W-50-run$run" -MinTests 1 -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
      Push-Location -LiteralPath $Clone
      cargo test -p mcao-backend-windows --locked --test interrupt
      Pop-Location
    }
  }
}
'STAGE-F2-DONE'

