. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-b shell: $shell"

Invoke-Row -Id 'W-06' -Command 'cargo test --workspace --locked --no-fail-fast' -Action {
  Push-Location -LiteralPath $Clone
  cargo test --workspace --locked --no-fail-fast
  Pop-Location
}
$w06log = Join-Path $Results 'logs\W-06.log'
Get-Content -LiteralPath $w06log | Where-Object { $_ -match '^(Running |running [0-9]+ tests|test result)' } |
  Set-Content -LiteralPath (Join-Path $Results 'W-06-summary.txt') -Encoding utf8

Invoke-Row -Id 'W-07' -Command 'cargo test -p mcao-core --locked --test error a_task_id_refused_at_creation' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --test error a_task_id_refused_at_creation
  Pop-Location
}
Invoke-Row -Id 'W-08' -Command 'cargo test -p mcao-core --locked --test state_encoding' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --test state_encoding
  Pop-Location
}
Invoke-Row -Id 'W-09' -Command 'cargo test -p mcao-core --locked --test home' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --test home
  Pop-Location
}
Invoke-Row -Id 'W-10' -Command 'cargo test -p mcao-core --locked --test windows_registry' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --test windows_registry
  Pop-Location
}
Invoke-Row -Id 'W-11' -Command 'cargo test -p mcao-core --locked --test preflight' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --test preflight
  Pop-Location
}
Invoke-Row -Id 'W-12' -Command 'cargo test -p mcao-core --locked --lib preflight' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --lib preflight
  Pop-Location
}
Invoke-Row -Id 'W-13' -Command 'cargo test -p mcao-cli --locked --test preflight' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --test preflight
  Pop-Location
}
Invoke-Row -Id 'W-14' -Command 'cargo test -p mcao-cli --locked --test cli' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --test cli
  Pop-Location
}
Invoke-Row -Id 'W-15' -Command 'cargo test -p mcao-cli --locked --test toolchain' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --test toolchain
  Pop-Location
}
Invoke-Row -Id 'W-16' -Command 'cargo test -p mcao-cli --locked --test herdr_lab_viewer' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --test herdr_lab_viewer
  Pop-Location
}
Invoke-Row -Id 'W-17' -Command 'cargo test -p mcao-cli --locked --test audit_validate --test audit_activity_map' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --test audit_validate --test audit_activity_map
  Pop-Location
}
Invoke-Row -Id 'W-18-linux' -MinTests 0 -Command 'cargo check --workspace --locked --target x86_64-unknown-linux-gnu' -Action {
  Push-Location -LiteralPath $Clone
  cargo check --workspace --locked --target x86_64-unknown-linux-gnu
  Pop-Location
}
Invoke-Row -Id 'W-18-darwin' -MinTests 0 -Command 'cargo check --workspace --locked --target aarch64-apple-darwin' -Action {
  Push-Location -LiteralPath $Clone
  cargo check --workspace --locked --target aarch64-apple-darwin
  Pop-Location
}
Invoke-Row -Id 'W-40' -Command 'cargo test -p mcao-core --locked --test state_encoding a_new_task_id_with_uppercase' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --test state_encoding a_new_task_id_with_uppercase
  Pop-Location
}
'STAGE-B-DONE'


