. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-e shell: $shell"
$mcao = Join-Path $Target 'debug\mcao.exe'
if (-not (Test-Path -LiteralPath $mcao)) { throw "mcao.exe missing: $mcao (run W-02 first)" }

Invoke-Row -Id 'W-41' -MinTests 0 -Command 'cargo test -p mcao-cli --locked --no-fail-fast --test audit_writer_cli' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --no-fail-fast --test audit_writer_cli
  Pop-Location
}
Invoke-Row -Id 'W-42' -MinTests 0 -Command 'cargo test -p mcao-cli --locked --no-fail-fast --test audit_writer_parity' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --no-fail-fast --test audit_writer_parity
  Pop-Location
}
Invoke-Row -Id 'W-43' -MinTests 1 -Command 'cargo test -p mcao-cli --locked --no-fail-fast --test hook_onedrive_guard' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --no-fail-fast --test hook_onedrive_guard
  Pop-Location
}
Invoke-Row -Id 'W-44' -MinTests 1 -Command 'cargo test -p mcao-cli --locked --no-fail-fast --test onedrive_guard' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --no-fail-fast --test onedrive_guard
  Pop-Location
}
Invoke-Row -Id 'W-45' -MinTests 1 -Command 'cargo test -p mcao-cli --locked --no-fail-fast --test hook_host_mirror' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --no-fail-fast --test hook_host_mirror
  Pop-Location
}
Invoke-Row -Id 'W-46' -MinTests 0 -Command 'cargo test -p mcao-cli --locked --no-fail-fast --test audit_baseline_parity' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-cli --locked --no-fail-fast --test audit_baseline_parity
  Pop-Location
}

# W-47: append takes the input file; verify and project-ledger take only --store
# (crates/mcao-cli/src/audit/writer.rs; run 20261103-r3 recorded the row-text ambiguity).
$fixture47 = Join-Path $Clone 'crates\mcao-cli\tests\fixtures\audit-validate\envelope-day-key-mismatch.json'
if (-not (Test-Path -LiteralPath $fixture47)) { throw "fixture missing: $fixture47" }
$storeAppend = Join-Path $Root 'w47-store-append'
$storeVerify = Join-Path $Root 'w47-store-verify'
$storeLedger = Join-Path $Root 'w47-store-project-ledger'
Invoke-Row -Id 'W-47-append' -MinTests 0 -Command 'mcao audit append --store <nonexistent under Root> fixture (expect exit 7 flock refusal)' -Action {
  & $mcao audit append --store $storeAppend $fixture47
  "Test-Path store after: $(Test-Path -LiteralPath $storeAppend)"
}
Invoke-Row -Id 'W-47-verify' -MinTests 0 -Command 'mcao audit verify --store <nonexistent under Root> (expect exit 7 flock refusal; verify takes only --store)' -Action {
  & $mcao audit verify --store $storeVerify
  "Test-Path store after: $(Test-Path -LiteralPath $storeVerify)"
}
Invoke-Row -Id 'W-47-project-ledger' -MinTests 0 -Command 'mcao audit project-ledger --store <nonexistent under Root> (expect exit 7 flock refusal; project-ledger takes only --store)' -Action {
  & $mcao audit project-ledger --store $storeLedger
  "Test-Path store after: $(Test-Path -LiteralPath $storeLedger)"
}

$auditChildPath = Join-Path $Results 'audit-validate-child.ps1'
if (-not (Test-Path -LiteralPath $auditChildPath)) { throw 'write the W-48 child script first (section 4.6 block)' }
$fixture48 = Join-Path $Clone 'crates\mcao-cli\tests\fixtures\audit-validate\envelope-actor-mismatch.json'
$dayKeyFixture = Join-Path $Clone 'crates\mcao-cli\tests\fixtures\audit-validate\envelope-day-key-mismatch.json'
New-Item -ItemType Directory -Force -Path (Join-Path $Root 'w48-a\mcao\home\state') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $Root 'w48-b') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $Root 'w48-c\mcao\home\state') | Out-Null

Invoke-Row -Id 'W-48-a' -MinTests 0 -Command 'mcao audit validate, unset FM_HOME, state directory present' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $auditChildPath -Mcao $mcao -LocalAppData (Join-Path $Root 'w48-a') -Document $fixture48
}
$rej = Join-Path $Root 'w48-a\mcao\home\state\audit-rejections.jsonl'
$rejCount = 0
if (Test-Path -LiteralPath $rej) { $rejCount = @(Get-Content -LiteralPath $rej).Count }
$rejNote = "W-48-a rejection file exists: $(Test-Path -LiteralPath $rej); lines: $rejCount"
$rejNote | Add-Content -LiteralPath (Join-Path $Results 'logs\W-48-a.log') -Encoding utf8
$rejNote

Invoke-Row -Id 'W-48-b' -MinTests 0 -Command 'mcao audit validate, unset FM_HOME, state directory absent' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $auditChildPath -Mcao $mcao -LocalAppData (Join-Path $Root 'w48-b') -Document $fixture48
}
$w48bFiles = @(Get-ChildItem -LiteralPath (Join-Path $Root 'w48-b') -Recurse -File -ErrorAction SilentlyContinue).Count
$w48bNote = "W-48-b files written under scratch: $w48bFiles"
$w48bNote | Add-Content -LiteralPath (Join-Path $Results 'logs\W-48-b.log') -Encoding utf8
$w48bNote

Invoke-Row -Id 'W-48-c' -MinTests 0 -Command 'mcao audit validate, day-key fixture, unset FM_HOME, state directory present (observation)' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $auditChildPath -Mcao $mcao -LocalAppData (Join-Path $Root 'w48-c') -Document $dayKeyFixture
}
$rejC = Join-Path $Root 'w48-c\mcao\home\state\audit-rejections.jsonl'
$rejCNote = "W-48-c rejection file exists: $(Test-Path -LiteralPath $rejC)"
$rejCNote | Add-Content -LiteralPath (Join-Path $Results 'logs\W-48-c.log') -Encoding utf8
$rejCNote

Remove-Item -LiteralPath (Join-Path $Root 'w48-a'), (Join-Path $Root 'w48-b'), (Join-Path $Root 'w48-c') -Recurse -Force -ErrorAction SilentlyContinue
'STAGE-E-DONE'

