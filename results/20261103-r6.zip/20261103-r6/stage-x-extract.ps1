$ErrorActionPreference = 'Continue'
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Results = Join-Path $Root '20261103-r6'

# 1. regenerate W-06-summary.txt with the corrected pattern (Running lines are indented)
$w06 = @(Get-Content -LiteralPath (Join-Path $Results 'logs\W-06.log'))
$summary = @($w06 | Where-Object { $_ -match '(\sRunning |^running [0-9]+ tests|^test result)' })
$summary | Set-Content -LiteralPath (Join-Path $Results 'W-06-summary.txt') -Encoding utf8
"W-06-summary.txt lines: $($summary.Count)"

# 2. W-06 failure detail for the report
$runningCount = @($w06 | Where-Object { $_ -match '^\s*Running ' }).Count
$zeroCount = @($w06 | Where-Object { $_ -match '^running 0 tests' }).Count
$passed = 0; $failed = 0; $ignored = 0; $resultLines = 0
foreach ($line in $w06) {
  if ($line -match '^test result: .*?([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored') {
    $resultLines++
    $passed += [int]$Matches[1]; $failed += [int]$Matches[2]; $ignored += [int]$Matches[3]
  }
}
$out = @()
$out += "total Running lines (binaries executed): $runningCount"
$out += "result lines: $resultLines; passed: $passed; failed: $failed; ignored: $ignored"
$out += "running-0-test binaries: $zeroCount"
$out += 'failing test marks:'
$out += @($w06 | Where-Object { $_ -cmatch '^test .* FAILED' })
$out += 'FAILED result lines:'
$out += @($w06 | Where-Object { $_ -cmatch '^test result: FAILED' })
$failStart = -1
for ($i = 0; $i -lt $w06.Count; $i++) { if ($w06[$i] -match '^failures:\s*$') { $failStart = $i; break } }
if ($failStart -ge 0) {
  $failEnd = $failStart
  for ($i = $failStart; $i -lt $w06.Count; $i++) { if ($w06[$i] -match '^test result: FAILED') { $failEnd = $i; break } }
  $out += '--- W-06 failure region ---'
  $out += $w06[$failStart..$failEnd]
}
$out | Set-Content -LiteralPath (Join-Path $Results 'W-06-failures.txt') -Encoding utf8
"W-06-failures.txt written"

# 3. W-21 failure detail if it failed
$w21path = Join-Path $Results 'logs\W-21.log'
if (Test-Path -LiteralPath $w21path) {
  $w21 = @(Get-Content -LiteralPath $w21path)
  $w21out = @()
  $failStart = -1
  for ($i = 0; $i -lt $w21.Count; $i++) { if ($w21[$i] -match '^failures:\s*$') { $failStart = $i; break } }
  if ($failStart -ge 0) {
    $w21out += '--- W-21 from first failures: to end ---'
    $w21out += $w21[$failStart..($w21.Count - 1)]
  } else {
    $w21out += 'no failures: line found; last 40 lines follow'
    $w21out += $w21[-40..-1]
  }
  $w21out | Set-Content -LiteralPath (Join-Path $Results 'W-21-failure-detail.txt') -Encoding utf8
  "W-21-failure-detail.txt written"
}

# 4. per-row digest: running N tests + test result lines for every row log except W-06
$digest = @()
Get-ChildItem -LiteralPath (Join-Path $Results 'logs') -File | Sort-Object Name | ForEach-Object {
  if ($_.Name -eq 'W-06.log') { return }
  $digest += "=== $($_.Name) ==="
  $digest += @(Get-Content -LiteralPath $_.FullName | Where-Object { $_ -match '^(running [0-9]+ tests|test result:|test .* FAILED)' })
}
$digest | Set-Content -LiteralPath (Join-Path $Results 'row-digest.txt') -Encoding utf8
"row-digest.txt written"
'EXTRACT-DONE'

