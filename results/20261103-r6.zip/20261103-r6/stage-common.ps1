$ErrorActionPreference = 'Continue'
$RunId = '20261103-r6'
if ($RunId -notmatch '^[A-Za-z0-9][A-Za-z0-9-]*$') { throw 'set $RunId to the RUN_ID of the Current request block' }
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Clone = Join-Path $Root 'src'
$Target = Join-Path $Root 'target'
$Results = Join-Path $Root $RunId
$RowsTsv = Join-Path $Results 'rows.tsv'
New-Item -ItemType Directory -Force -Path (Join-Path $Results 'logs') | Out-Null
$env:CARGO_TARGET_DIR = $Target
$shell = (Get-Process -Id $PID).Path

function Invoke-Row {
  param([string]$Id, [string]$Command, [int]$MinTests = 1, [scriptblock]$Action)
  $log = Join-Path (Join-Path $Results 'logs') "$Id.log"
  $start = Get-Date
  $lines = @(& $Action 2>&1 | ForEach-Object { "$_" })
  $code = $LASTEXITCODE
  $lines | Out-File -FilePath $log -Encoding utf8
  $secs = [int]((Get-Date) - $start).TotalSeconds
  $ran = @($lines | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
  $vacuous = ($MinTests -gt 0) -and ($ran -eq 0)
  "$Id`t$code`t$secs`tbinaries-with-tests=$ran`tvacuous=$vacuous`t$Command" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  "$Id exit=$code duration=${secs}s binaries-with-tests=$ran vacuous=$vacuous"
}

