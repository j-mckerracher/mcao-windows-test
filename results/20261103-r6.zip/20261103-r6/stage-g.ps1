. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-g shell: $shell"

$nativeSh = Join-Path $Clone 'bin\fm-sessionstart-nudge.sh'
$pyProbePath = Join-Path $Results 'w54-zone-probe.py'
$gitChildPath = Join-Path $Results 'w56-git-child.ps1'
$harmlessSh = Join-Path $Results 'w52-probe.sh'
Set-Content -LiteralPath $harmlessSh -Value '# harmless probe file: a comment only, never run as a script' -Encoding ascii

function Invoke-ChildCapture {
  param([string]$FileName, [string]$Arguments, [hashtable]$ChildEnv, [int]$TimeoutMs = 120000)
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $FileName
  $psi.Arguments = $Arguments
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.EnvironmentVariables.Clear()
  foreach ($key in $ChildEnv.Keys) { $psi.EnvironmentVariables[$key] = $ChildEnv[$key] }
  $proc = [System.Diagnostics.Process]::Start($psi)
  $stdoutTask = $proc.StandardOutput.ReadToEndAsync()
  $stderrTask = $proc.StandardError.ReadToEndAsync()
  if ($proc.WaitForExit($TimeoutMs)) {
    $global:LASTEXITCODE = $proc.ExitCode
    "child exit=$($proc.ExitCode)"
  } else {
    & taskkill.exe /PID $proc.Id /T /F | Out-Null
    [void]$proc.WaitForExit(10000)
    $global:LASTEXITCODE = 'TIMEOUT'
    "child exit=TIMEOUT: killed with its process tree at $TimeoutMs ms"
  }
  [void]$stdoutTask.Wait(10000)
  [void]$stderrTask.Wait(10000)
  "child stdout: $(if ($stdoutTask.IsCompleted) { $stdoutTask.Result })"
  "child stderr: $(if ($stderrTask.IsCompleted) { $stderrTask.Result })"
}

function Invoke-Bounded {
  param([string]$FileName, [string[]]$Arguments, [int]$TimeoutMs = 60000)
  $quoted = @($Arguments | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } })
  $base = Join-Path $Results ('bounded-' + [guid]::NewGuid().ToString('N'))
  try {
    $proc = Start-Process -FilePath $FileName -ArgumentList $quoted -NoNewWindow -PassThru -RedirectStandardOutput "$base.out" -RedirectStandardError "$base.err"
  } catch {
    "START FAILED: $($_.Exception.Message)"
    $global:LASTEXITCODE = 1
    return
  }
  if ($proc.WaitForExit($TimeoutMs)) {
    $global:LASTEXITCODE = $proc.ExitCode
  } else {
    & taskkill.exe /PID $proc.Id /T /F | Out-Null
    [void]$proc.WaitForExit(10000)
    $global:LASTEXITCODE = 'TIMEOUT'
    "TIMEOUT: killed with its process tree at $TimeoutMs ms"
  }
  foreach ($file in "$base.out", "$base.err") {
    if (Test-Path -LiteralPath $file) {
      Get-Content -LiteralPath $file
      Remove-Item -LiteralPath $file
    }
  }
}

$gitChildScript = @'
param([string]$Repo)
Set-Location -LiteralPath $Repo
git init -q . ; "init exit=$LASTEXITCODE"
Set-Content -LiteralPath f.txt -Value 'probe' -Encoding ascii
git add f.txt ; "add exit=$LASTEXITCODE"
git -c user.name=probe -c user.email=probe@example.invalid commit -q -m probe ; "commit exit=$LASTEXITCODE"
git config --show-origin --list ; "config-list exit=$LASTEXITCODE"
'@
Set-Content -LiteralPath $gitChildPath -Value $gitChildScript -Encoding utf8

$pyProbeScript = @'
import importlib.util
import sys
import zoneinfo
print("python", sys.version.split()[0], sys.platform)
print("TZPATH", zoneinfo.TZPATH)
print("tzdata installed:", importlib.util.find_spec("tzdata") is not None)
try:
    zoneinfo.ZoneInfo("America/Chicago")
    print("ZoneInfo America/Chicago: loads")
except Exception as error:
    print("ZoneInfo America/Chicago: fails", type(error).__name__, error)
'@
Set-Content -LiteralPath $pyProbePath -Value $pyProbeScript -Encoding utf8

Invoke-Row -Id 'W-51' -MinTests 0 -Command 'child pwsh, env PATH and TMPDIR only: GetTempPath' -Action {
  "parent GetTempPath: $([System.IO.Path]::GetTempPath())"
  Invoke-ChildCapture -FileName $shell -Arguments '-NoProfile -Command "[System.IO.Path]::GetTempPath()"' -ChildEnv @{ PATH = $env:Path; TMPDIR = (Join-Path $Root 'w51-tmpdir') }
}

Invoke-Row -Id 'W-52' -MinTests 0 -Command 'direct launch of the comment-only w52-probe.sh in the run folder, no shell' -Action {
  try {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $harmlessSh
    $psi.UseShellExecute = $false
    $proc = [System.Diagnostics.Process]::Start($psi)
    if ($proc.WaitForExit(60000)) {
      "started; exit=$($proc.ExitCode)"
      $global:LASTEXITCODE = 0
    } else {
      & taskkill.exe /PID $proc.Id /T /F | Out-Null
      [void]$proc.WaitForExit(10000)
      'TIMEOUT: started and did not exit within 60000 ms; killed with its process tree'
      $global:LASTEXITCODE = 'TIMEOUT'
    }
  } catch [System.ComponentModel.Win32Exception] {
    "Win32Exception NativeErrorCode=$($_.Exception.NativeErrorCode): $($_.Exception.Message)"
    $global:LASTEXITCODE = 0
  }
}

Invoke-Row -Id 'W-53' -MinTests 0 -Command 'bash: where.exe, bash --version, test -r on backslash and forward-slash paths (bounded; Git bash by full path; WSL launcher never started)' -Action {
  $timedOut = $false
  $whereLines = @(Invoke-Bounded -FileName 'where.exe' -Arguments @('bash') -TimeoutMs 30000)
  $whereLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $timedOut = $true }
  $bashExe = @("$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $bashExe) {
    $bashExe = $whereLines | Where-Object { $_ -match '\\bash\.exe$' -and $_ -notlike "$env:SystemRoot\*" } | Select-Object -First 1
  }
  if (-not $bashExe) {
    'SKIPPED: WSL launcher only (no Git for Windows bash and no bash outside System32); bash not started'
    $global:LASTEXITCODE = 0
    return
  }
  "bash used (full path): $bashExe"
  $versionLines = @(Invoke-Bounded -FileName $bashExe -Arguments @('--version') -TimeoutMs 30000)
  $versionLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $timedOut = $true }
  $fwd = $nativeSh -replace '\\', '/'
  foreach ($form in @($nativeSh, $fwd)) {
    "form=$form"
    $readLines = @(Invoke-Bounded -FileName $bashExe -Arguments @('-c', "test -r '$form' && echo readable || echo unreadable") -TimeoutMs 30000)
    $readLines
    if ("$LASTEXITCODE" -eq 'TIMEOUT') { $timedOut = $true }
  }
  if ($timedOut) { $global:LASTEXITCODE = 'TIMEOUT' } else { $global:LASTEXITCODE = 0 }
}

Invoke-Row -Id 'W-54' -MinTests 0 -Command 'python zone facts and reference on the day-key fixture (bounded)' -Action {
  $pyCommand = Get-Command python -ErrorAction SilentlyContinue
  if (-not $pyCommand) {
    'SKIPPED: python absent (no python on PATH)'
    $global:LASTEXITCODE = 0
    return
  }
  $pyExe = $pyCommand.Source
  $versionLines = @(Invoke-Bounded -FileName $pyExe -Arguments @('--version') -TimeoutMs 30000)
  $versionLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $global:LASTEXITCODE = 'TIMEOUT'; return }
  if ("$LASTEXITCODE" -ne '0' -or (($versionLines -join ' ') -notmatch 'Python \d')) {
    'SKIPPED: python absent (python --version did not exit 0 with a Python x.y line; the Microsoft Store alias fails this check)'
    $global:LASTEXITCODE = 0
    return
  }
  $zoneLines = @(Invoke-Bounded -FileName $pyExe -Arguments @($pyProbePath) -TimeoutMs 60000)
  $zoneLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $global:LASTEXITCODE = 'TIMEOUT'; return }
  $stateDir = Join-Path $Results 'w54-state'
  New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
  $fixture = Join-Path $Clone 'crates\mcao-cli\tests\fixtures\audit-validate\envelope-day-key-mismatch.json'
  $oldState = $env:FM_STATE_OVERRIDE
  $env:FM_STATE_OVERRIDE = $stateDir
  try {
    $refLines = @(Invoke-Bounded -FileName $pyExe -Arguments @((Join-Path $Clone 'bin\fm-audit-envelope.py'), 'validate', $fixture) -TimeoutMs 60000)
    $refLines
    $refCode = $LASTEXITCODE
    "reference exit=$refCode"
  } finally {
    $env:FM_STATE_OVERRIDE = $oldState
    Remove-Item -LiteralPath $stateDir -Recurse -Force -ErrorAction SilentlyContinue
  }
  if ("$refCode" -eq 'TIMEOUT') { $global:LASTEXITCODE = 'TIMEOUT' } else { $global:LASTEXITCODE = 0 }
}

Invoke-Row -Id 'W-55' -MinTests 0 -Command '[System.IO.File]::Open on a directory' -Action {
  $dir = Join-Path $Root 'w55-dir'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  try {
    $stream = [System.IO.File]::Open($dir, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
    $stream.Dispose()
    'opened a directory handle'
  } catch {
    "exception: $($_.Exception.GetType().FullName): $($_.Exception.Message)"
  }
  Remove-Item -LiteralPath $dir -Recurse -Force
  $global:LASTEXITCODE = 0
}

Invoke-Row -Id 'W-56' -MinTests 0 -Command 'child git init, add, commit, config origins with PATH, PATHEXT, GIT_CONFIG_NOSYSTEM=1, GIT_CONFIG_GLOBAL=/dev/null only' -Action {
  $repo = Join-Path $Root 'w56-repo'
  Remove-Item -LiteralPath $repo -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $repo | Out-Null
  Invoke-ChildCapture -FileName $shell -Arguments "-NoProfile -ExecutionPolicy Bypass -File `"$gitChildPath`" -Repo `"$repo`"" -ChildEnv @{ PATH = $env:Path; PATHEXT = '.COM;.EXE;.BAT;.CMD'; GIT_CONFIG_NOSYSTEM = '1'; GIT_CONFIG_GLOBAL = '/dev/null' }
  Remove-Item -LiteralPath $repo -Recurse -Force -ErrorAction SilentlyContinue
}

Invoke-Row -Id 'W-57' -MinTests 0 -Command 'presence, length, and drive-rooted shape of profile and OneDrive variables (no path text)' -Action {
  foreach ($name in 'USERPROFILE', 'LOCALAPPDATA', 'OneDrive', 'OneDriveCommercial', 'OneDriveConsumer') {
    $value = [System.Environment]::GetEnvironmentVariable($name)
    if ([string]::IsNullOrEmpty($value)) { "${name}: empty" } else { "${name}: set, length $($value.Length), drive-rooted: $($value -match '^[A-Za-z]:\\')" }
  }
  $global:LASTEXITCODE = 0
}

# ---------- W-58 (section 4.9, corrected r6 block, verbatim) ----------
Invoke-Row -Id 'W-58' -MinTests 0 -Command 'escalation test launched five ways in one session (diagnostic; only with NOTES: rerun W-21)' -Action {
  $w58Notes = @(Get-Content -LiteralPath (Join-Path $Clone 'docs\windows-native-verification.md') -ErrorAction Stop | Where-Object { $_ -cmatch '^NOTES: ' })
  if (-not (($w58Notes.Count -gt 0) -and ($w58Notes[0] -ceq 'NOTES: rerun W-21'))) {
    'W-58 SKIPPED: reason not requested'
    $global:LASTEXITCODE = 0
    return
  }
  $env:CARGO_TARGET_DIR = $Target
  $shell = (Get-Process -Id $PID).Path
  $ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $rowBudgetMs = 1800000
  $runLimitMs = 120000
  $rowStart = Get-Date
  $rowTimedOut = $false
  "psHost=$($Host.Name) shell=$($PSVersionTable.PSVersion) stdinRedirected=$([Console]::IsInputRedirected) stdoutRedirected=$([Console]::IsOutputRedirected)"
  $ancestor = (Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$PID" -ErrorAction SilentlyContinue).ParentProcessId
  for ($depth = 1; $depth -le 5; $depth++) {
    if (-not $ancestor) { break }
    $proc = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$ancestor" -ErrorAction SilentlyContinue
    if (-not $proc) { break }
    "ancestor$depth=$($proc.Name) pid=$($proc.ProcessId)"
    $ancestor = $proc.ParentProcessId
  }
  $w58Test = 'escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait'
  $w58Args = @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', $w58Test, '--', '--exact')
  $w58Line = "cargo test -p mcao-backend-windows --locked --test interrupt $w58Test -- --exact"
  # Build once, bounded by the row budget, so the timed runs do not include compilation. Its exit code is recorded.
  $buildOut = Join-Path $Results 'W-58-build.out'
  $buildErr = Join-Path $Results 'W-58-build.err'
  $buildLimitMs = $rowBudgetMs - [int]((Get-Date) - $rowStart).TotalMilliseconds
  $build = Start-Process -FilePath 'cargo' -ArgumentList @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', '--no-run') -WorkingDirectory $Clone -NoNewWindow -PassThru -RedirectStandardOutput $buildOut -RedirectStandardError $buildErr
  if ($build.WaitForExit($buildLimitMs)) {
    $buildCode = $build.ExitCode
  } else {
    & taskkill.exe /PID $build.Id /T /F | Out-Null
    [void]$build.WaitForExit(10000)
    $buildCode = 'TIMEOUT'
  }
  $buildText = @()
  foreach ($file in $buildOut, $buildErr) {
    if (Test-Path -LiteralPath $file) {
      $buildText += @(Get-Content -LiteralPath $file)
      Remove-Item -LiteralPath $file
    }
  }
  $buildText
  "build exit=$buildCode"
  if ("$buildCode" -ne '0') {
    'build failed: the five variants were not run; last 30 lines of build output follow'
    $buildText | Select-Object -Last 30
    $global:LASTEXITCODE = $buildCode
    return
  }
  foreach ($variant in 'direct-start-process', 'in-process', 'child-powershell51', 'cmd-c', 'new-console-window') {
    for ($run = 1; $run -le 3; $run++) {
      $outFile = Join-Path $Results "W-58-$variant-$run.out"
      $errFile = Join-Path $Results "W-58-$variant-$run.err"
      $spentMs = [int]((Get-Date) - $rowStart).TotalMilliseconds
      $limitMs = [Math]::Min($runLimitMs, $rowBudgetMs - $spentMs)
      if ($limitMs -le 0) {
        $rowTimedOut = $true
        "variant=$variant run=$run exit=TIMEOUT: row budget ended before this run"
        continue
      }
      $startArgs = @{ WorkingDirectory = $Clone; PassThru = $true }
      switch ($variant) {
        'direct-start-process' { $startArgs += @{ FilePath = 'cargo'; ArgumentList = $w58Args; NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'in-process' { $startArgs += @{ FilePath = $shell; ArgumentList = @('-NoProfile', '-Command', "& cargo $($w58Args -join ' '); exit `$LASTEXITCODE"); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'child-powershell51' { $startArgs += @{ FilePath = $ps51; ArgumentList = @('-NoProfile', '-Command', "$w58Line; exit `$LASTEXITCODE"); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'cmd-c' { $startArgs += @{ FilePath = $env:ComSpec; ArgumentList = @('/c', $w58Line); NoNewWindow = $true; RedirectStandardOutput = $outFile; RedirectStandardError = $errFile } }
        'new-console-window' { $startArgs += @{ FilePath = $env:ComSpec; ArgumentList = @('/c', "$w58Line > `"$outFile`" 2>&1") } }
      }
      $started = Start-Process @startArgs
      if ($started.WaitForExit($limitMs)) {
        $code = $started.ExitCode
      } else {
        & taskkill.exe /PID $started.Id /T /F | Out-Null
        [void]$started.WaitForExit(10000)
        $code = 'TIMEOUT'
        if ($limitMs -lt $runLimitMs) { $rowTimedOut = $true }
      }
      $text = @()
      foreach ($file in $outFile, $errFile) {
        if (Test-Path -LiteralPath $file) {
          $text += @(Get-Content -LiteralPath $file)
          Remove-Item -LiteralPath $file
        }
      }
      "variant=$variant run=$run exit=$code"
      $text
      $hits = @($text | Where-Object { $_ -match 'panicked at|left:|right:|both reach the stub|test result|^running' })
      "variant=$variant run=$run filtered: $($hits -join ' | ')"
      if ("$code" -ne '0') {
        "variant=$variant run=$run last 30 lines:"
        $text | Select-Object -Last 30
      }
    }
  }
  if ($rowTimedOut) {
    'W-58 row TIMEOUT: the 30-minute row budget ended the loop; runs marked TIMEOUT above did not complete'
    $global:LASTEXITCODE = 'TIMEOUT'
    return
  }
  $global:LASTEXITCODE = 0
}

# ---------- final close ----------
$closeLines = @()
Push-Location -LiteralPath $Clone
$closeLines += 'git status --porcelain after last row:'
$closeLines += @(git status --porcelain)
Pop-Location
$closeLines += "clone clean: $($closeLines.Count -eq 1)"
$closeLines | Out-File -FilePath (Join-Path $Results 'logs\close.log') -Encoding utf8
$closeLines
'STAGE-G-DONE'

