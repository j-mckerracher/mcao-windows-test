. (Join-Path $PSScriptRoot 'r4-common.ps1')
"r4 shell: $shell"
"targeted run: W-01 plus ROWS W-21,W-56; NOTES 'rerun W-21' opens the W-49/W-50 gate"

# ---------- W-01 (always part of a targeted run) ----------
Invoke-Row -Id 'W-01' -MinTests 0 -Command 'rustup show active-toolchain; rustc -V; cargo -V; rustc -Vv (inside the test checkout)' -Action {
  Push-Location -LiteralPath $Clone
  rustup show active-toolchain
  rustc -V
  cargo -V
  rustc -Vv
  Pop-Location
}

# ---------- W-21 ----------
Invoke-Row -Id 'W-21' -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test interrupt
  Pop-Location
}

# ---------- W-49 (section 4.8 loop, verbatim shape) ----------
$packetNotes = @(Get-Content -LiteralPath (Join-Path $Clone 'docs\windows-native-verification.md') -ErrorAction Stop | Where-Object { $_ -cmatch '^NOTES: ' })
$RerunRequested = ($packetNotes.Count -gt 0) -and ($packetNotes[0] -ceq 'NOTES: rerun W-21')
$summary = Join-Path $Results 'W-49-summary.txt'
if (-not $RerunRequested) {
  'W-49 SKIPPED: reason not requested'
} else {
  $rerunLog = Join-Path $Results 'logs\W-49-rerun.txt'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $rerunLog) | Out-Null
  "W-49 log file: $rerunLog" | Add-Content -LiteralPath $summary -Encoding utf8
  $rerunArgs = @('test', '-p', 'mcao-backend-windows', '--locked', '--test', 'interrupt', 'escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait', '--', '--exact')
  $rerunCommand = 'cargo test -p mcao-backend-windows --locked --test interrupt escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait -- --exact'
  $rowBudgetMs = 1800000
  $runLimitMs = 600000
  $passes = 0
  $failures = 0
  $rowTimedOut = $false
  $rowStart = Get-Date
  for ($run = 1; $run -le 20; $run++) {
    $spentMs = [int]((Get-Date) - $rowStart).TotalMilliseconds
    $limitMs = [Math]::Min($runLimitMs, $rowBudgetMs - $spentMs)
    if ($limitMs -le 0) { $rowTimedOut = $true; break }
    $outFile = Join-Path $Results "W-49-run$run.out"
    $errFile = Join-Path $Results "W-49-run$run.err"
    $runStart = Get-Date
    $proc = Start-Process -FilePath 'cargo' -ArgumentList $rerunArgs -WorkingDirectory $Clone -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
    $finished = $proc.WaitForExit($limitMs)
    if (-not $finished) {
      & taskkill.exe /PID $proc.Id /T /F | Out-Null
      [void]$proc.WaitForExit(10000)
    }
    $secs = [int]((Get-Date) - $runStart).TotalSeconds
    $out = @()
    foreach ($file in $outFile, $errFile) {
      if (Test-Path -LiteralPath $file) {
        $out += @(Get-Content -LiteralPath $file)
        Remove-Item -LiteralPath $file
      }
    }
    $code = if ($finished) { $proc.ExitCode } else { 'TIMEOUT' }
    $ran = @($out | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
    if ($finished -and $code -eq 0) { $passes++ } else { $failures++ }
    "run=$run exit=$code" | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Add-Content -LiteralPath $rerunLog -Encoding utf8
    $out | Where-Object { $_ -match 'panicked at|left:|right:|test result' } | ForEach-Object { "run=$run $_" } | Add-Content -LiteralPath $summary -Encoding utf8
    if (-not $finished) { "run=$run TIMEOUT: killed with its process tree at $limitMs ms" | Add-Content -LiteralPath $summary -Encoding utf8 }
    "W-49-run$run`t$code`t$secs`tbinaries-with-tests=$ran`tvacuous=$($ran -eq 0)`t$rerunCommand" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
    if (-not $finished -and $limitMs -lt $runLimitMs) { $rowTimedOut = $true; break }
  }
  if ($rowTimedOut) {
    "row TIMEOUT: the 30-minute row budget ended the loop at run $run" | Add-Content -LiteralPath $summary -Encoding utf8
    "W-49-row`tTIMEOUT`t`tbinaries-with-tests=0`tvacuous=n/a`trow stopped at its 30-minute budget at run $run" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  }
  "passes=$passes failures=$failures" | Add-Content -LiteralPath $summary -Encoding utf8
  "W-49: passes=$passes failures=$failures"
}

# ---------- W-50 (section 4.8, three whole-binary runs) ----------
if (-not $RerunRequested) {
  'W-50 SKIPPED: reason not requested'
} else {
  foreach ($run in 1..3) {
    Invoke-Row -Id "W-50-run$run" -MinTests 1 -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
      Push-Location -LiteralPath $Clone
      cargo test -p mcao-backend-windows --locked --test interrupt
      Pop-Location
    }
  }
}

# ---------- W-56 (section 4.9 row with the r4 PATHEXT fix) ----------
$gitChildScript = @'
param([string]$Repo)
Set-Location -LiteralPath $Repo
git init -q . ; "init exit=$LASTEXITCODE"
Set-Content -LiteralPath f.txt -Value 'probe' -Encoding ascii
git add f.txt ; "add exit=$LASTEXITCODE"
git -c user.name=probe -c user.email=probe@example.invalid commit -q -m probe ; "commit exit=$LASTEXITCODE"
git config --show-origin --list ; "config-list exit=$LASTEXITCODE"
'@
$gitChildPath = Join-Path $Results 'w56-git-child.ps1'
Set-Content -LiteralPath $gitChildPath -Value $gitChildScript -Encoding utf8

function Invoke-ChildCapture {
  param([string]$FileName, [string]$Arguments, [hashtable]$ChildEnv, [int]$TimeoutMs = 120000)
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $FileName
  $psi.Arguments = $Arguments
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.EnvironmentVariables.Clear()
  foreach ($key in $ChildEnv.Keys) { $psi.EnvironmentVariables[$key] = $ChildEnv[$key] }
  $proc = [System.Diagnostics.Process]::Start($psi)
  $stdoutTask = $proc.StandardOutput.ReadToEndAsync()
  $stderrTask = $proc.StandardError.ReadToEndAsync()
  if ($proc.WaitForExit($TimeoutMs)) {
    $global:LASTEXITCODE = $proc.ExitCode
    "child exit=$($proc.ExitCode)"
  } else {
    & taskkill.exe /PID $proc.Id /T /F | Out-Null
    [void]$proc.WaitForExit(10000)
    $global:LASTEXITCODE = 'TIMEOUT'
    "child exit=TIMEOUT: killed with its process tree at $TimeoutMs ms"
  }
  [void]$stdoutTask.Wait(10000)
  [void]$stderrTask.Wait(10000)
  "child stdout: $(if ($stdoutTask.IsCompleted) { $stdoutTask.Result })"
  "child stderr: $(if ($stderrTask.IsCompleted) { $stderrTask.Result })"
}

Invoke-Row -Id 'W-56' -MinTests 0 -Command 'child git init, add, commit, config origins with PATH, PATHEXT, GIT_CONFIG_NOSYSTEM=1, GIT_CONFIG_GLOBAL=/dev/null only' -Action {
  $repo = Join-Path $Root 'w56-repo'
  Remove-Item -LiteralPath $repo -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $repo | Out-Null
  Invoke-ChildCapture -FileName $shell -Arguments "-NoProfile -ExecutionPolicy Bypass -File `"$gitChildPath`" -Repo `"$repo`"" -ChildEnv @{ PATH = $env:Path; PATHEXT = '.COM;.EXE;.BAT;.CMD'; GIT_CONFIG_NOSYSTEM = '1'; GIT_CONFIG_GLOBAL = '/dev/null' }
  Remove-Item -LiteralPath $repo -Recurse -Force -ErrorAction SilentlyContinue
}

# ---------- close ----------
$closeLines = @()
Push-Location -LiteralPath $Clone
$closeLines += 'git status --porcelain after last row:'
$closeLines += @(git status --porcelain)
Pop-Location
$closeLines += "clone clean: $($closeLines.Count -eq 1)"
$closeLines | Out-File -FilePath (Join-Path $Results 'logs\close.log') -Encoding utf8
$closeLines
'R4-DONE'

