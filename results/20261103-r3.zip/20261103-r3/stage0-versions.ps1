$ErrorActionPreference = 'Continue'
$RunId = '20261103-r3'
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Clone = Join-Path $Root 'src'
$Target = Join-Path $Root 'target'
$Results = Join-Path $Root $RunId
$env:CARGO_TARGET_DIR = $Target
$shell = (Get-Process -Id $PID).Path

$lines = @()
$lines += "shell: $shell"
$lines += "PSVersion: $($PSVersionTable.PSVersion.ToString()) PSEdition: $($PSVersionTable.PSEdition)"
$lines += "OSVersion: $([System.Environment]::OSVersion.VersionString)"
$lines += "OSCaption: $((Get-CimInstance Win32_OperatingSystem).Caption)"
$lines += "OSBuildNumber: $((Get-CimInstance Win32_OperatingSystem).BuildNumber)"
$lines += "PROCESSOR_ARCHITECTURE: $env:PROCESSOR_ARCHITECTURE"
$lines += "git: $(git --version)"
$lines += '--- inside the test checkout ---'
Push-Location -LiteralPath $Clone
$lines += "rustup show active-toolchain (inside): $(rustup show active-toolchain)"
$lines += "rustc -V (inside): $(rustc -V)"
$lines += "cargo -V (inside): $(cargo -V)"
foreach ($l in @(rustc -Vv)) { $lines += "rustc -Vv (inside): $l" }
Pop-Location
$lines += '--- outside the test checkout ---'
$lines += "rustup show active-toolchain (outside): $(rustup show active-toolchain)"
$lines += "rustc -V (outside): $(rustc -V)"
$lines += '--- installed targets ---'
foreach ($l in @(rustup target list --installed)) { $lines += "target installed: $l" }
$lines | Out-File -FilePath (Join-Path $Results 'versions.txt') -Encoding utf8
$lines
'VERSIONS-DONE'

