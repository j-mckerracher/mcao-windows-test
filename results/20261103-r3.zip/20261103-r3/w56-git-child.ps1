param([string]$Repo)
Set-Location -LiteralPath $Repo
git init -q . ; "init exit=$LASTEXITCODE"
Set-Content -LiteralPath f.txt -Value 'probe' -Encoding ascii
git add f.txt ; "add exit=$LASTEXITCODE"
git -c user.name=probe -c user.email=probe@example.invalid commit -q -m probe ; "commit exit=$LASTEXITCODE"
git config --show-origin --list ; "config-list exit=$LASTEXITCODE"

