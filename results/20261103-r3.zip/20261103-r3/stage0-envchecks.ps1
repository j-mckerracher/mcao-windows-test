$ErrorActionPreference = 'Continue'
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Results = Join-Path $Root '20261103-r3'
$lines = @()
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (Test-Path -LiteralPath $vswhere) {
  $vsPath = @(& $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath)
  $lines += "vswhere installationPath: $(if ($vsPath) { $vsPath -join ' ' } else { '(nothing printed)' })"
} else {
  $lines += 'vswhere.exe not found'
}
$linkPaths = @(Get-Command link.exe -All -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike "$env:SystemRoot*" } | Select-Object -ExpandProperty Source)
$lines += "link.exe outside system folder: $(if ($linkPaths) { $linkPaths -join ' ' } else { '(none)' })"
$id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$pr = New-Object System.Security.Principal.WindowsPrincipal($id)
$lines += "running elevated: $($pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator))"
$longpaths = git config --get core.longpaths
$lines += "core.longpaths (global git config): $(if ($null -ne $longpaths) { $longpaths } else { '(unset)' })"
$lp = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name LongPathsEnabled -ErrorAction SilentlyContinue
$lines += "LongPathsEnabled (registry): $($lp.LongPathsEnabled)"
$lines += "OneDrive var set: $([bool]$env:OneDrive)"
$lines += "OneDriveCommercial var set: $([bool]$env:OneDriveCommercial)"
$lines += "OneDriveConsumer var set: $([bool]$env:OneDriveConsumer)"
$lines += "USERPROFILE drive-rooted: $($env:USERPROFILE -match '^[A-Za-z]:\\')"
$lines += "rustup --version: $(rustup --version)"
$lines | Out-File -FilePath (Join-Path $Results 'env-checks.txt') -Encoding utf8
$lines
'ENVCHECKS-DONE'

