param([string]$Mcao, [string]$LocalAppData, [string]$Document)
Remove-Item Env:FM_HOME -ErrorAction SilentlyContinue
Remove-Item Env:FM_STATE_OVERRIDE -ErrorAction SilentlyContinue
$env:LOCALAPPDATA = $LocalAppData
& $Mcao audit validate $Document
exit $LASTEXITCODE

