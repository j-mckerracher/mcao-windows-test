$ErrorActionPreference = 'Continue'
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Results = Join-Path $Root '20261103-r3'

# 1. regenerate W-06-summary.txt with the corrected pattern (Running lines are indented)
$w06 = @(Get-Content -LiteralPath (Join-Path $Results 'logs\W-06.log'))
$summary = @($w06 | Where-Object { $_ -match '(\sRunning |^running [0-9]+ tests|^test result)' })
$summary | Set-Content -LiteralPath (Join-Path $Results 'W-06-summary.txt') -Encoding utf8
"W-06-summary.txt lines: $($summary.Count)"

# 2. W-06 failure detail for the report
$runningCount = @($w06 | Where-Object { $_ -match '^\s*Running ' }).Count
$out = @()
$out += "total Running lines (binaries executed): $runningCount"
$out += 'failing test marks:'
$out += @($w06 | Where-Object { $_ -match '^test .* FAILED' })
$out += 'FAILED result lines:'
$out += @($w06 | Where-Object { $_ -match '^test result: FAILED' })
$zero = @()
for ($i = 0; $i -lt $w06.Count; $i++) {
  if ($w06[$i] -match '^running 0 tests') {
    $j = $i
    while ($j -ge 0 -and $w06[$j] -notmatch '^\s*Running ') { $j-- }
    $zero += ($w06[$j] -replace '^\s*', '')
  }
}
$out += "running-0-test binaries: $($zero.Count)"
$out += $zero
# panic blocks: from the first 'failures:' line to the FAILED result line
$failStart = -1
for ($i = 0; $i -lt $w06.Count; $i++) { if ($w06[$i] -match '^failures:\s*$') { $failStart = $i; break } }
if ($failStart -ge 0) {
  $failEnd = $failStart
  for ($i = $failStart; $i -lt $w06.Count; $i++) { if ($w06[$i] -match '^test result: FAILED') { $failEnd = $i; break } }
  $out += '--- W-06 failure region (interrupt binary) ---'
  $out += $w06[$failStart..$failEnd]
}
$out | Set-Content -LiteralPath (Join-Path $Results 'W-06-failures.txt') -Encoding utf8
"W-06-failures.txt written"

# 3. W-21 failure detail: from the first 'failures:' line to the end, plus last 30 lines
$w21 = @(Get-Content -LiteralPath (Join-Path $Results 'logs\W-21.log'))
$w21out = @()
$failStart = -1
for ($i = 0; $i -lt $w21.Count; $i++) { if ($w21[$i] -match '^failures:\s*$') { $failStart = $i; break } }
if ($failStart -ge 0) {
  $w21out += '--- W-21 from first failures: to end ---'
  $w21out += $w21[$failStart..($w21.Count - 1)]
} else {
  $w21out += 'no failures: line found; last 40 lines follow'
  $w21out += $w21[-40..-1]
}
$w21out | Set-Content -LiteralPath (Join-Path $Results 'W-21-failure-detail.txt') -Encoding utf8
"W-21-failure-detail.txt written"

# 4. per-row digest: running N tests + test result lines for every row log except W-06
$digest = @()
Get-ChildItem -LiteralPath (Join-Path $Results 'logs') -File | Sort-Object Name | ForEach-Object {
  if ($_.Name -eq 'W-06.log') { return }
  $digest += "=== $($_.Name) ==="
  $digest += @(Get-Content -LiteralPath $_.FullName | Where-Object { $_ -match '^(running [0-9]+ tests|test result:|test .* FAILED)' })
}
$digest | Set-Content -LiteralPath (Join-Path $Results 'row-digest.txt') -Encoding utf8
"row-digest.txt written"
'EXTRACT-DONE'

