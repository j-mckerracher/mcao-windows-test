. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-f shell: $shell"
$mcao = Join-Path $Target 'debug\mcao.exe'
if (-not (Test-Path -LiteralPath $mcao)) { throw "mcao.exe missing: $mcao" }
$preflightPath = Join-Path $Results 'preflight-child.ps1'
if (-not (Test-Path -LiteralPath $preflightPath)) { throw 'write the preflight child script first (section 4.7 block)' }

$ghPresent = [bool](Get-Command gh -ErrorAction SilentlyContinue)
"real gh on PATH: $ghPresent"
$GhStub = Join-Path $Results 'gh-stub'
if (-not $ghPresent) {
  New-Item -ItemType Directory -Force -Path $GhStub | Out-Null
  Set-Content -LiteralPath (Join-Path $GhStub 'gh.exe') -Value 'not a program' -Encoding ascii
}
$pathValue = $env:Path
if (-not $ghPresent) { $pathValue = "$GhStub;$env:Path" }

Invoke-Row -Id 'W-31' -MinTests 0 -Command 'mcao.exe --version' -Action { & $mcao --version }
Invoke-Row -Id 'W-32' -MinTests 0 -Command 'mcao.exe --help' -Action { & $mcao --help }

if ($ghPresent) {
  Invoke-Row -Id 'W-33' -MinTests 0 -Command 'mcao preflight, Git and real gh on PATH, FM_HOME absent' -Action {
    & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $pathValue -FmHome '' -OneDriveVar '' -OneDriveValue '' -UserProfile ''
  }
} else {
  "W-33`tSKIPPED`t`t`tvacuous=n/a`tgh absent" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  'W-33 SKIPPED: gh absent'
}

Invoke-Row -Id 'W-34' -MinTests 0 -Command 'mcao preflight, Git missing (System32 PATH child, ExpectGitMissing)' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue "$env:SystemRoot\System32" -ExpectGitMissing
}

$fmHome = Join-Path $env:TEMP 'mcao winverify 有人 ÄÖ'
New-Item -ItemType Directory -Force -Path $fmHome | Out-Null
Invoke-Row -Id 'W-35' -MinTests 0 -Command 'mcao preflight, spaces and non-ASCII FM_HOME' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $pathValue -FmHome $fmHome -OneDriveVar '' -OneDriveValue '' -UserProfile ''
}
Remove-Item -LiteralPath $fmHome -Recurse -Force -ErrorAction SilentlyContinue

$uncHome = '\\localhost\c$\Users\' + $env:USERNAME + '\AppData\Local\Temp\mcao-winverify-unc'
if (-not (Test-Path -LiteralPath '\\localhost\c$\Users')) {
  "W-36`tSKIPPED`t`t`tvacuous=n/a`tadmin share unreachable" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  'W-36 SKIPPED: admin share unreachable'
} else {
  Invoke-Row -Id 'W-36' -MinTests 0 -Command 'mcao preflight, UNC FM_HOME as text only' -Action {
    & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $pathValue -FmHome $uncHome -OneDriveVar '' -OneDriveValue '' -UserProfile ''
  }
}

$odRoot = Join-Path $env:TEMP 'OneDrive-winverify'
New-Item -ItemType Directory -Force -Path $odRoot | Out-Null
$odHome = Join-Path $odRoot 'home'
New-Item -ItemType Directory -Force -Path $odHome | Out-Null
foreach ($varName in 'OneDrive', 'OneDriveCommercial', 'OneDriveConsumer') {
  Invoke-Row -Id "W-37-$varName" -MinTests 0 -Command "mcao preflight, OneDrive root via $varName" -Action {
    & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $pathValue -FmHome $odHome -OneDriveVar $varName -OneDriveValue $odRoot -UserProfile ''
  }
}

$profileRoot = Join-Path $env:TEMP 'mcao-winverify-profile'
New-Item -ItemType Directory -Force -Path (Join-Path $profileRoot 'OneDrive - winverify\home') | Out-Null
Invoke-Row -Id 'W-37b' -MinTests 0 -Command 'mcao preflight, profile sync folder warning only' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $pathValue -FmHome (Join-Path $profileRoot 'OneDrive - winverify\home') -OneDriveVar '' -OneDriveValue '' -UserProfile $profileRoot
}

Invoke-Row -Id 'W-38' -Command 'cargo test -p mcao-core --locked --test preflight the_default_home' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-core --locked --test preflight the_default_home
  Pop-Location
}

# W-39 is a reference to W-13; no separate run (recorded in SUMMARY.md).
# W-49 and W-50 run only when the NOTES key line is exactly 'NOTES: rerun W-21'; this request has NOTES: none.
"W-49`tSKIPPED`t`t`tvacuous=n/a`tnot requested" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
"W-50`tSKIPPED`t`t`tvacuous=n/a`tnot requested" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
'W-49 SKIPPED: not requested'
'W-50 SKIPPED: not requested'

$closeLines = @()
Push-Location -LiteralPath $Clone
$closeLines += 'git status --porcelain after last row:'
$closeLines += @(git status --porcelain)
Pop-Location
if (-not $ghPresent) { Remove-Item -LiteralPath $GhStub -Recurse -Force -ErrorAction SilentlyContinue }
Remove-Item -LiteralPath $odRoot -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $profileRoot -Recurse -Force -ErrorAction SilentlyContinue
$closeLines += "clone clean: $($closeLines.Count -eq 1)"
$closeLines | Out-File -FilePath (Join-Path $Results 'logs\close.log') -Encoding utf8
$closeLines
'STAGE-F-DONE'

