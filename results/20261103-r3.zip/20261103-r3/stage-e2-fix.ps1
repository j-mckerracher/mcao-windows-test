. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-e2 shell: $shell"
$mcao = Join-Path $Target 'debug\mcao.exe'
if (-not (Test-Path -LiteralPath $mcao)) { throw "mcao.exe missing: $mcao" }
$storeVerify = Join-Path $Root 'w47-store-verify'
$storeLedger = Join-Path $Root 'w47-store-project-ledger'

# The packet's W-47 row text says 'the same shape for verify --store $store and project-ledger
# --store $store'; the CLI (crates/mcao-cli/src/audit/writer.rs:38-50) takes only --store for
# those two subcommands. The first attempt passed the fixture positionally and got a usage
# error (exit 2). This is the corrected run of the same rows; both attempts stay in the log.

$verifyLog = Join-Path $Results 'logs\W-47-verify.log'
$verifyBefore = @(Get-Content -LiteralPath $verifyLog)
Invoke-Row -Id 'W-47-verify' -MinTests 0 -Command 'mcao audit verify --store <nonexistent under Root> (expect exit 7 flock refusal; corrected shape, no input file)' -Action {
  & $mcao audit verify --store $storeVerify
  "Test-Path store after: $(Test-Path -LiteralPath $storeVerify)"
}
$verifyAfter = @(Get-Content -LiteralPath $verifyLog)
@('--- first attempt (fixture passed positionally; usage error, exit 2) ---') + $verifyBefore +
  @('--- corrected run (verify takes only --store) ---') + $verifyAfter |
  Set-Content -LiteralPath $verifyLog -Encoding utf8

$ledgerLog = Join-Path $Results 'logs\W-47-project-ledger.log'
$ledgerBefore = @(Get-Content -LiteralPath $ledgerLog)
Invoke-Row -Id 'W-47-project-ledger' -MinTests 0 -Command 'mcao audit project-ledger --store <nonexistent under Root> (expect exit 7 flock refusal; corrected shape, no input file)' -Action {
  & $mcao audit project-ledger --store $storeLedger
  "Test-Path store after: $(Test-Path -LiteralPath $storeLedger)"
}
$ledgerAfter = @(Get-Content -LiteralPath $ledgerLog)
@('--- first attempt (fixture passed positionally; usage error, exit 2) ---') + $ledgerBefore +
  @('--- corrected run (project-ledger takes only --store) ---') + $ledgerAfter |
  Set-Content -LiteralPath $ledgerLog -Encoding utf8

'STAGE-E2-DONE'

