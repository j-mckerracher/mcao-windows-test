# harmless probe file: a comment only, never run as a script
