. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-g shell: $shell"

$nativeSh = Join-Path $Clone 'bin\fm-sessionstart-nudge.sh'
$pyProbePath = Join-Path $Results 'w54-zone-probe.py'
$gitChildPath = Join-Path $Results 'w56-git-child.ps1'
$harmlessSh = Join-Path $Results 'w52-probe.sh'
Set-Content -LiteralPath $harmlessSh -Value '# harmless probe file: a comment only, never run as a script' -Encoding ascii

function Invoke-ChildCapture {
  param([string]$FileName, [string]$Arguments, [hashtable]$ChildEnv, [int]$TimeoutMs = 120000)
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $FileName
  $psi.Arguments = $Arguments
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.EnvironmentVariables.Clear()
  foreach ($key in $ChildEnv.Keys) { $psi.EnvironmentVariables[$key] = $ChildEnv[$key] }
  $proc = [System.Diagnostics.Process]::Start($psi)
  $stdoutTask = $proc.StandardOutput.ReadToEndAsync()
  $stderrTask = $proc.StandardError.ReadToEndAsync()
  if ($proc.WaitForExit($TimeoutMs)) {
    $global:LASTEXITCODE = $proc.ExitCode
    "child exit=$($proc.ExitCode)"
  } else {
    & taskkill.exe /PID $proc.Id /T /F | Out-Null
    [void]$proc.WaitForExit(10000)
    $global:LASTEXITCODE = 'TIMEOUT'
    "child exit=TIMEOUT: killed with its process tree at $TimeoutMs ms"
  }
  [void]$stdoutTask.Wait(10000)
  [void]$stderrTask.Wait(10000)
  "child stdout: $(if ($stdoutTask.IsCompleted) { $stdoutTask.Result })"
  "child stderr: $(if ($stderrTask.IsCompleted) { $stderrTask.Result })"
}

function Invoke-Bounded {
  param([string]$FileName, [string[]]$Arguments, [int]$TimeoutMs = 60000)
  $quoted = @($Arguments | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } })
  $base = Join-Path $Results ('bounded-' + [guid]::NewGuid().ToString('N'))
  try {
    $proc = Start-Process -FilePath $FileName -ArgumentList $quoted -NoNewWindow -PassThru -RedirectStandardOutput "$base.out" -RedirectStandardError "$base.err"
  } catch {
    "START FAILED: $($_.Exception.Message)"
    $global:LASTEXITCODE = 1
    return
  }
  if ($proc.WaitForExit($TimeoutMs)) {
    $global:LASTEXITCODE = $proc.ExitCode
  } else {
    & taskkill.exe /PID $proc.Id /T /F | Out-Null
    [void]$proc.WaitForExit(10000)
    $global:LASTEXITCODE = 'TIMEOUT'
    "TIMEOUT: killed with its process tree at $TimeoutMs ms"
  }
  foreach ($file in "$base.out", "$base.err") {
    if (Test-Path -LiteralPath $file) {
      Get-Content -LiteralPath $file
      Remove-Item -LiteralPath $file
    }
  }
}

$gitChildScript = @'
param([string]$Repo)
Set-Location -LiteralPath $Repo
git init -q . ; "init exit=$LASTEXITCODE"
Set-Content -LiteralPath f.txt -Value 'probe' -Encoding ascii
git add f.txt ; "add exit=$LASTEXITCODE"
git -c user.name=probe -c user.email=probe@example.invalid commit -q -m probe ; "commit exit=$LASTEXITCODE"
git config --show-origin --list ; "config-list exit=$LASTEXITCODE"
'@
Set-Content -LiteralPath $gitChildPath -Value $gitChildScript -Encoding utf8

$pyProbeScript = @'
import importlib.util
import sys
import zoneinfo
print("python", sys.version.split()[0], sys.platform)
print("TZPATH", zoneinfo.TZPATH)
print("tzdata installed:", importlib.util.find_spec("tzdata") is not None)
try:
    zoneinfo.ZoneInfo("America/Chicago")
    print("ZoneInfo America/Chicago: loads")
except Exception as error:
    print("ZoneInfo America/Chicago: fails", type(error).__name__, error)
'@
Set-Content -LiteralPath $pyProbePath -Value $pyProbeScript -Encoding utf8

Invoke-Row -Id 'W-51' -MinTests 0 -Command 'child pwsh, env PATH and TMPDIR only: GetTempPath' -Action {
  "parent GetTempPath: $([System.IO.Path]::GetTempPath())"
  Invoke-ChildCapture -FileName $shell -Arguments '-NoProfile -Command "[System.IO.Path]::GetTempPath()"' -ChildEnv @{ PATH = $env:Path; TMPDIR = (Join-Path $Root 'w51-tmpdir') }
}

Invoke-Row -Id 'W-52' -MinTests 0 -Command 'direct launch of the comment-only w52-probe.sh in the run folder, no shell' -Action {
  try {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $harmlessSh
    $psi.UseShellExecute = $false
    $proc = [System.Diagnostics.Process]::Start($psi)
    if ($proc.WaitForExit(60000)) {
      "started; exit=$($proc.ExitCode)"
      $global:LASTEXITCODE = 0
    } else {
      & taskkill.exe /PID $proc.Id /T /F | Out-Null
      [void]$proc.WaitForExit(10000)
      'TIMEOUT: started and did not exit within 60000 ms; killed with its process tree'
      $global:LASTEXITCODE = 'TIMEOUT'
    }
  } catch [System.ComponentModel.Win32Exception] {
    "Win32Exception NativeErrorCode=$($_.Exception.NativeErrorCode): $($_.Exception.Message)"
    $global:LASTEXITCODE = 0
  }
}

Invoke-Row -Id 'W-53' -MinTests 0 -Command 'bash: where.exe, bash --version, test -r on backslash and forward-slash paths (bounded; Git bash by full path; WSL launcher never started)' -Action {
  $timedOut = $false
  $whereLines = @(Invoke-Bounded -FileName 'where.exe' -Arguments @('bash') -TimeoutMs 30000)
  $whereLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $timedOut = $true }
  $bashExe = @("$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $bashExe) {
    $bashExe = $whereLines | Where-Object { $_ -match '\\bash\.exe$' -and $_ -notlike "$env:SystemRoot\*" } | Select-Object -First 1
  }
  if (-not $bashExe) {
    'SKIPPED: WSL launcher only (no Git for Windows bash and no bash outside System32); bash not started'
    $global:LASTEXITCODE = 0
    return
  }
  "bash used (full path): $bashExe"
  $versionLines = @(Invoke-Bounded -FileName $bashExe -Arguments @('--version') -TimeoutMs 30000)
  $versionLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $timedOut = $true }
  $fwd = $nativeSh -replace '\\', '/'
  foreach ($form in @($nativeSh, $fwd)) {
    "form=$form"
    $readLines = @(Invoke-Bounded -FileName $bashExe -Arguments @('-c', "test -r '$form' && echo readable || echo unreadable") -TimeoutMs 30000)
    $readLines
    if ("$LASTEXITCODE" -eq 'TIMEOUT') { $timedOut = $true }
  }
  if ($timedOut) { $global:LASTEXITCODE = 'TIMEOUT' } else { $global:LASTEXITCODE = 0 }
}

Invoke-Row -Id 'W-54' -MinTests 0 -Command 'python zone facts and reference on the day-key fixture (bounded)' -Action {
  $pyCommand = Get-Command python -ErrorAction SilentlyContinue
  if (-not $pyCommand) {
    'SKIPPED: python absent (no python on PATH)'
    $global:LASTEXITCODE = 0
    return
  }
  $pyExe = $pyCommand.Source
  $versionLines = @(Invoke-Bounded -FileName $pyExe -Arguments @('--version') -TimeoutMs 30000)
  $versionLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $global:LASTEXITCODE = 'TIMEOUT'; return }
  if ("$LASTEXITCODE" -ne '0' -or (($versionLines -join ' ') -notmatch 'Python \d')) {
    'SKIPPED: python absent (python --version did not exit 0 with a Python x.y line; the Microsoft Store alias fails this check)'
    $global:LASTEXITCODE = 0
    return
  }
  $zoneLines = @(Invoke-Bounded -FileName $pyExe -Arguments @($pyProbePath) -TimeoutMs 60000)
  $zoneLines
  if ("$LASTEXITCODE" -eq 'TIMEOUT') { $global:LASTEXITCODE = 'TIMEOUT'; return }
  $stateDir = Join-Path $Results 'w54-state'
  New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
  $fixture = Join-Path $Clone 'crates\mcao-cli\tests\fixtures\audit-validate\envelope-day-key-mismatch.json'
  $oldState = $env:FM_STATE_OVERRIDE
  $env:FM_STATE_OVERRIDE = $stateDir
  try {
    $refLines = @(Invoke-Bounded -FileName $pyExe -Arguments @((Join-Path $Clone 'bin\fm-audit-envelope.py'), 'validate', $fixture) -TimeoutMs 60000)
    $refLines
    $refCode = $LASTEXITCODE
    "reference exit=$refCode"
  } finally {
    $env:FM_STATE_OVERRIDE = $oldState
    Remove-Item -LiteralPath $stateDir -Recurse -Force -ErrorAction SilentlyContinue
  }
  if ("$refCode" -eq 'TIMEOUT') { $global:LASTEXITCODE = 'TIMEOUT' } else { $global:LASTEXITCODE = 0 }
}

Invoke-Row -Id 'W-55' -MinTests 0 -Command '[System.IO.File]::Open on a directory' -Action {
  $dir = Join-Path $Root 'w55-dir'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  try {
    $stream = [System.IO.File]::Open($dir, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
    $stream.Dispose()
    'opened a directory handle'
  } catch {
    "exception: $($_.Exception.GetType().FullName): $($_.Exception.Message)"
  }
  Remove-Item -LiteralPath $dir -Recurse -Force
  $global:LASTEXITCODE = 0
}

Invoke-Row -Id 'W-56' -MinTests 0 -Command 'child git init, add, commit, config origins with PATH, GIT_CONFIG_NOSYSTEM=1, GIT_CONFIG_GLOBAL=/dev/null only' -Action {
  $repo = Join-Path $Root 'w56-repo'
  Remove-Item -LiteralPath $repo -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $repo | Out-Null
  Invoke-ChildCapture -FileName $shell -Arguments "-NoProfile -ExecutionPolicy Bypass -File `"$gitChildPath`" -Repo `"$repo`"" -ChildEnv @{ PATH = $env:Path; GIT_CONFIG_NOSYSTEM = '1'; GIT_CONFIG_GLOBAL = '/dev/null' }
  Remove-Item -LiteralPath $repo -Recurse -Force -ErrorAction SilentlyContinue
}

Invoke-Row -Id 'W-57' -MinTests 0 -Command 'presence, length, and drive-rooted shape of profile and OneDrive variables (no path text)' -Action {
  foreach ($name in 'USERPROFILE', 'LOCALAPPDATA', 'OneDrive', 'OneDriveCommercial', 'OneDriveConsumer') {
    $value = [System.Environment]::GetEnvironmentVariable($name)
    if ([string]::IsNullOrEmpty($value)) { "${name}: empty" } else { "${name}: set, length $($value.Length), drive-rooted: $($value -match '^[A-Za-z]:\\')" }
  }
  $global:LASTEXITCODE = 0
}
'STAGE-G-DONE'

