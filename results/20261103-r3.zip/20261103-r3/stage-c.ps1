. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-c shell: $shell"

Invoke-Row -Id 'W-19' -Command 'cargo test -p mcao-backend-windows --locked --test job' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test job
  Pop-Location
}
Invoke-Row -Id 'W-20' -Command 'cargo test -p mcao-backend-windows --locked --test backend' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test backend
  Pop-Location
}
Invoke-Row -Id 'W-21' -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test interrupt
  Pop-Location
}
Invoke-Row -Id 'W-22' -Command 'cargo test -p mcao-backend-windows --locked --test conpty' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test conpty
  Pop-Location
}
Invoke-Row -Id 'W-23' -Command 'cargo test -p mcao-backend-windows --locked --test console_pipe' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test console_pipe
  Pop-Location
}
Invoke-Row -Id 'W-24' -Command 'cargo test -p mcao-backend-windows --locked --test pipe' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --test pipe
  Pop-Location
}
Invoke-Row -Id 'W-25' -Command 'cargo test -p mcao-backend-windows --locked --lib console_server' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --lib console_server
  Pop-Location
}
Invoke-Row -Id 'W-26' -Command 'cargo test -p mcao-backend-windows --locked --lib' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-backend-windows --locked --lib
  Pop-Location
}
Invoke-Row -Id 'W-27' -Command 'cargo test -p mcao-probe --locked --test native' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-probe --locked --test native
  Pop-Location
}
'STAGE-C-DONE'

