. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-f2 shell: $shell"
# capture-fidelity fix only: decode native stdout as UTF-8 so the non-ASCII FM_HOME path
# is logged as printed. No row command or child script changes.
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$mcao = Join-Path $Target 'debug\mcao.exe'
$preflightPath = Join-Path $Results 'preflight-child.ps1'
if (-not (Test-Path -LiteralPath $preflightPath)) { throw 'preflight-child.ps1 missing' }

$fmHome = Join-Path $env:TEMP 'mcao winverify 有人 ÄÖ'
New-Item -ItemType Directory -Force -Path $fmHome | Out-Null
$w35Log = Join-Path $Results 'logs\W-35.log'
$w35Before = @(Get-Content -LiteralPath $w35Log)
Invoke-Row -Id 'W-35' -MinTests 0 -Command 'mcao preflight, spaces and non-ASCII FM_HOME (rerun with UTF-8 console decoding for a clean log; first attempt passed with an encoding artifact in the capture)' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $env:Path -FmHome $fmHome -OneDriveVar '' -OneDriveValue '' -UserProfile ''
}
Remove-Item -LiteralPath $fmHome -Recurse -Force -ErrorAction SilentlyContinue
$w35After = @(Get-Content -LiteralPath $w35Log)
@('--- first attempt (ANSI console decode artifact in the capture; exit 0) ---') + $w35Before +
  @('--- rerun with UTF-8 console decoding ---') + $w35After |
  Set-Content -LiteralPath $w35Log -Encoding utf8
'STAGE-F2-DONE'

