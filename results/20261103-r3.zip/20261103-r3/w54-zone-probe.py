import importlib.util
import sys
import zoneinfo
print("python", sys.version.split()[0], sys.platform)
print("TZPATH", zoneinfo.TZPATH)
print("tzdata installed:", importlib.util.find_spec("tzdata") is not None)
try:
    zoneinfo.ZoneInfo("America/Chicago")
    print("ZoneInfo America/Chicago: loads")
except Exception as error:
    print("ZoneInfo America/Chicago: fails", type(error).__name__, error)
