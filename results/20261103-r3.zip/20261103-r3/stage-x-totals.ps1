$ErrorActionPreference = 'Continue'
$Results = Join-Path (Join-Path $env:LOCALAPPDATA 'mcao-winverify') '20261103-r3'
$w06 = @(Get-Content -LiteralPath (Join-Path $Results 'logs\W-06.log'))
$passed = 0; $failed = 0; $ignored = 0; $resultLines = 0
foreach ($line in $w06) {
  if ($line -match '^test result: .*?([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored') {
    $resultLines++
    $passed += [int]$Matches[1]; $failed += [int]$Matches[2]; $ignored += [int]$Matches[3]
  }
}
"W-06 totals: $resultLines result lines; $passed passed; $failed failed; $ignored ignored"
"gh: $((gh --version | Select-Object -First 1))"
"UTC now: $((Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))"

