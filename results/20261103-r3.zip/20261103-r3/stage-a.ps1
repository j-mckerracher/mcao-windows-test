. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-a shell: $shell"

Invoke-Row -Id 'W-01' -MinTests 0 -Command 'rustup show active-toolchain; rustc -V; cargo -V; rustc -Vv (inside the test checkout)' -Action {
  Push-Location -LiteralPath $Clone
  rustup show active-toolchain
  rustc -V
  cargo -V
  rustc -Vv
  Pop-Location
}

Invoke-Row -Id 'W-02' -MinTests 0 -Command 'cargo build -p mcao-cli --locked --bin mcao' -Action {
  Push-Location -LiteralPath $Clone
  cargo build -p mcao-cli --locked --bin mcao
  Pop-Location
  $bin = Join-Path $Target 'debug\mcao.exe'
  if (Test-Path -LiteralPath $bin) { Get-Item -LiteralPath $bin | Format-List FullName, Length, LastWriteTime } else { "mcao.exe NOT FOUND: $bin" }
}

Invoke-Row -Id 'W-03' -MinTests 0 -Command 'cargo build -p mcao-probe --locked --target x86_64-pc-windows-msvc' -Action {
  Push-Location -LiteralPath $Clone
  cargo build -p mcao-probe --locked --target x86_64-pc-windows-msvc
  Pop-Location
  $bin = Join-Path $Target 'x86_64-pc-windows-msvc\debug\mcao-probe.exe'
  if (Test-Path -LiteralPath $bin) { Get-Item -LiteralPath $bin | Format-List FullName, Length, LastWriteTime } else { "mcao-probe.exe NOT FOUND: $bin" }
}

Invoke-Row -Id 'W-04' -MinTests 0 -Command 'cargo check --workspace --locked --target x86_64-pc-windows-msvc' -Action {
  Push-Location -LiteralPath $Clone
  cargo check --workspace --locked --target x86_64-pc-windows-msvc
  Pop-Location
}

Invoke-Row -Id 'W-05' -MinTests 0 -Command 'cargo clippy --workspace --all-targets --locked -- -D warnings' -Action {
  Push-Location -LiteralPath $Clone
  cargo clippy --workspace --all-targets --locked -- -D warnings
  Pop-Location
}
'STAGE-A-DONE'

