. (Join-Path $PSScriptRoot 'stage-common.ps1')
"stage-d shell: $shell"

$probeScriptPath = Join-Path $Results 'bash-free-probe.ps1'
if (-not (Test-Path -LiteralPath $probeScriptPath)) { throw 'write the probe script first (section 4.4 block)' }
$probeExe = Join-Path $Target 'x86_64-pc-windows-msvc\debug\mcao-probe.exe'
if (-not (Test-Path -LiteralPath $probeExe)) { throw "probe exe missing: $probeExe" }

Invoke-Row -Id 'W-28' -MinTests 0 -Command '& shell -NoProfile -ExecutionPolicy Bypass -File bash-free-probe.ps1 (probe) (results)' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $probeScriptPath -ProbeExe $probeExe -OutDir $Results
}

$proofPath = Join-Path $Results 'bash-free-path.json'
$proof = Get-Content -LiteralPath $proofPath -Raw | ConvertFrom-Json
$w29pass = ($proof.command_missing_after.bash -eq $true -and $proof.command_missing_after.sh -eq $true -and $proof.command_missing_after.wsl -eq $true)
$w29lines = @(
  "removed_directories=$($proof.removed_directories) kept_directories=$($proof.kept_directories)"
  "forbidden_found_on_path=$($proof.forbidden_found_on_path -join ', ')"
  "bash missing after: $($proof.command_missing_after.bash)"
  "sh   missing after: $($proof.command_missing_after.sh)"
  "wsl  missing after: $($proof.command_missing_after.wsl)"
  "W-29 verdict: $(if ($w29pass) { 'PASS' } else { 'FAIL' })"
)
$w29lines | Out-File -FilePath (Join-Path $Results 'logs\W-29.log') -Encoding utf8
$w29lines

Invoke-Row -Id 'W-30' -Command 'cargo test -p mcao-probe --locked --test platform_leakage' -Action {
  Push-Location -LiteralPath $Clone
  cargo test -p mcao-probe --locked --test platform_leakage
  Pop-Location
}
'STAGE-D-DONE'

