$ErrorActionPreference = 'Continue'
$RunId = '20261103-r7'
if ($RunId -notmatch '^[A-Za-z0-9][A-Za-z0-9-]*$') { throw 'set $RunId to the RUN_ID of the Current request block' }
$Root = Join-Path $env:LOCALAPPDATA 'mcao-winverify'
$Clone = Join-Path $Root 'src'
$Target = Join-Path $Root 'target'
$Results = Join-Path $Root $RunId
$RowsTsv = Join-Path $Results 'rows.tsv'
New-Item -ItemType Directory -Force -Path (Join-Path $Results 'logs') | Out-Null
$env:CARGO_TARGET_DIR = $Target
$shell = (Get-Process -Id $PID).Path

function Invoke-Row {
  param([string]$Id, [string]$Command, [int]$MinTests = 1, [scriptblock]$Action)
  $log = Join-Path (Join-Path $Results 'logs') "$Id.log"
  $start = Get-Date
  $lines = @(& $Action 2>&1 | ForEach-Object { "$_" })
  $code = $LASTEXITCODE
  $lines | Out-File -FilePath $log -Encoding utf8
  $secs = [int]((Get-Date) - $start).TotalSeconds
  $ran = @($lines | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
  $vacuous = ($MinTests -gt 0) -and ($ran -eq 0)
  "$Id`t$code`t$secs`tbinaries-with-tests=$ran`tvacuous=$vacuous`t$Command" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  "$Id exit=$code duration=${secs}s binaries-with-tests=$ran vacuous=$vacuous"
}

"r7 shell: $shell"
"targeted run: W-01 plus ROWS W-18; NOTES 'none' leaves W-49, W-50, and W-58 skipped"

# ---------- W-01 (always part of a targeted run) ----------
Invoke-Row -Id 'W-01' -MinTests 0 -Command 'rustup show active-toolchain; rustc -V; cargo -V; rustc -Vv (inside the test checkout)' -Action {
  Push-Location -LiteralPath $Clone
  rustup show active-toolchain
  rustc -V
  cargo -V
  rustc -Vv
  Pop-Location
}

# ---------- W-18 (r7 exclude form) ----------
Invoke-Row -Id 'W-18-linux' -MinTests 0 -Command 'cargo check --workspace --exclude mcao-cli --locked --target x86_64-unknown-linux-gnu' -Action {
  Push-Location -LiteralPath $Clone
  cargo check --workspace --exclude mcao-cli --locked --target x86_64-unknown-linux-gnu
  Pop-Location
}
Invoke-Row -Id 'W-18-darwin' -MinTests 0 -Command 'cargo check --workspace --exclude mcao-cli --locked --target aarch64-apple-darwin' -Action {
  Push-Location -LiteralPath $Clone
  cargo check --workspace --exclude mcao-cli --locked --target aarch64-apple-darwin
  Pop-Location
}

# ---------- gated rows not requested ----------
"W-49`tSKIPPED`t`t`tvacuous=n/a`tnot requested" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
"W-50`tSKIPPED`t`t`tvacuous=n/a`tnot requested" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
'W-49 SKIPPED: not requested'
'W-50 SKIPPED: not requested'
'W-58 SKIPPED: not requested (no rows.tsv line for observation rows; recorded in SUMMARY)'

# ---------- close ----------
$closeLines = @()
Push-Location -LiteralPath $Clone
$closeLines += 'git status --porcelain after last row:'
$closeLines += @(git status --porcelain)
Pop-Location
$closeLines += "clone clean: $($closeLines.Count -eq 1)"
$closeLines | Out-File -FilePath (Join-Path $Results 'logs\close.log') -Encoding utf8
$closeLines
'R7-DONE'

