
Set-Location -LiteralPath $env:LOCALAPPDATA\mcao-winverify\src
$eol = @(git ls-files --eol)
$crlfText = @($eol | Where-Object { $_ -match '\bw/crlf\b' -and $_ -notmatch 'attr/-text' })
$lfText = @($eol | Where-Object { $_ -match '\bw/lf\b' -and $_ -match 'attr/text' })
"crlf-text=$($crlfText.Count) lf-text=$($lfText.Count)"
if ($crlfText.Count -gt 0) { $crlfText[0..2] }
