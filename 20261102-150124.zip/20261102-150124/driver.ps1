$ErrorActionPreference = 'Continue'
$Clone = Join-Path $env:LOCALAPPDATA 'mcao-winverify\src'
$RunId = '20261102-150124'
$Results = Join-Path $env:LOCALAPPDATA "mcao-winverify\$RunId"
$RowsTsv = Join-Path $Results 'rows.tsv'
$shell = (Get-Process -Id $PID).Path
"driver shell: $shell"

function Invoke-Row {
  param([string]$Id, [string]$Command, [int]$MinTests = 1, [scriptblock]$Action)
  $log = Join-Path (Join-Path $Results 'logs') "$Id.log"
  $start = Get-Date
  $lines = @(& $Action 2>&1 | ForEach-Object { "$_" })
  $code = $LASTEXITCODE
  $lines | Out-File -FilePath $log -Encoding utf8
  $secs = [int]((Get-Date) - $start).TotalSeconds
  $ran = @($lines | Where-Object { $_ -match '^running [1-9][0-9]* tests?$' }).Count
  $vacuous = ($MinTests -gt 0) -and ($ran -eq 0)
  "$Id`t$code`t$secs`tran-binaries=$ran`tvacuous=$vacuous`t$Command" | Add-Content -LiteralPath $RowsTsv -Encoding utf8
  "$Id exit=$code duration=${secs}s binaries-with-tests=$ran vacuous=$vacuous"
}

# ---------- 4.1 toolchain and build ----------
Invoke-Row -Id 'W-01' -MinTests 0 -Command 'rustup show active-toolchain; rustc -Vv' -Action {
  Set-Location -LiteralPath $Clone; rustup show active-toolchain; rustc -Vv
}
Invoke-Row -Id 'W-02' -MinTests 0 -Command 'cargo build -p mcao-cli --locked --bin mcao' -Action {
  Set-Location -LiteralPath $Clone; cargo build -p mcao-cli --locked --bin mcao
}
Invoke-Row -Id 'W-03' -MinTests 0 -Command 'cargo build -p mcao-probe --locked --target x86_64-pc-windows-msvc' -Action {
  Set-Location -LiteralPath $Clone; cargo build -p mcao-probe --locked --target x86_64-pc-windows-msvc
}
Invoke-Row -Id 'W-04' -MinTests 0 -Command 'cargo check --workspace --locked --target x86_64-pc-windows-msvc' -Action {
  Set-Location -LiteralPath $Clone; cargo check --workspace --locked --target x86_64-pc-windows-msvc
}
Invoke-Row -Id 'W-05' -MinTests 0 -Command 'cargo clippy --workspace --all-targets --locked -- -D warnings' -Action {
  Set-Location -LiteralPath $Clone; cargo clippy --workspace --all-targets --locked -- -D warnings
}

# ---------- 4.2 workspace and per-crate tests ----------
Invoke-Row -Id 'W-06' -Command 'cargo test --workspace --locked' -Action {
  Set-Location -LiteralPath $Clone; cargo test --workspace --locked
}
$w06log = Join-Path $Results 'logs\W-06.log'
Get-Content -LiteralPath $w06log | Where-Object { $_ -match '^test result' -or $_ -match '^running' } |
  Set-Content -LiteralPath (Join-Path $Results 'W-06-grep.txt') -Encoding utf8

Invoke-Row -Id 'W-07' -Command 'cargo test -p mcao-core --locked --test error a_task_id_refused_at_creation' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --test error a_task_id_refused_at_creation
}
Invoke-Row -Id 'W-08' -Command 'cargo test -p mcao-core --locked --test state_encoding' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --test state_encoding
}
Invoke-Row -Id 'W-09' -Command 'cargo test -p mcao-core --locked --test home' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --test home
}
Invoke-Row -Id 'W-10' -Command 'cargo test -p mcao-core --locked --test windows_registry' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --test windows_registry
}
Invoke-Row -Id 'W-11' -Command 'cargo test -p mcao-core --locked --test preflight' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --test preflight
}
Invoke-Row -Id 'W-12' -Command 'cargo test -p mcao-core --locked --lib preflight' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --lib preflight
}
Invoke-Row -Id 'W-13' -Command 'cargo test -p mcao-cli --locked --test preflight' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-cli --locked --test preflight
}
Invoke-Row -Id 'W-14' -Command 'cargo test -p mcao-cli --locked --test cli' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-cli --locked --test cli
}
Invoke-Row -Id 'W-15' -Command 'cargo test -p mcao-cli --locked --test toolchain' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-cli --locked --test toolchain
}
Invoke-Row -Id 'W-16' -Command 'cargo test -p mcao-cli --locked --test herdr_lab_viewer' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-cli --locked --test herdr_lab_viewer
}
Invoke-Row -Id 'W-17' -Command 'cargo test -p mcao-cli --locked --test audit_validate --test audit_activity_map' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-cli --locked --test audit_validate --test audit_activity_map
}

Invoke-Row -Id 'W-18-linux' -MinTests 0 -Command 'cargo check --workspace --locked --target x86_64-unknown-linux-gnu' -Action {
  Set-Location -LiteralPath $Clone; cargo check --workspace --locked --target x86_64-unknown-linux-gnu
}
Invoke-Row -Id 'W-18-darwin' -MinTests 0 -Command 'cargo check --workspace --locked --target aarch64-apple-darwin' -Action {
  Set-Location -LiteralPath $Clone; cargo check --workspace --locked --target aarch64-apple-darwin
}

Invoke-Row -Id 'W-40' -Command 'cargo test -p mcao-core --locked --test state_encoding a_new_task_id_with_uppercase' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --test state_encoding a_new_task_id_with_uppercase
}

# ---------- 4.3 windows backend and console ----------
Invoke-Row -Id 'W-19' -Command 'cargo test -p mcao-backend-windows --locked --test job' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --test job
}
Invoke-Row -Id 'W-20' -Command 'cargo test -p mcao-backend-windows --locked --test backend' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --test backend
}
Invoke-Row -Id 'W-21' -Command 'cargo test -p mcao-backend-windows --locked --test interrupt' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --test interrupt
}
Invoke-Row -Id 'W-22' -Command 'cargo test -p mcao-backend-windows --locked --test conpty' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --test conpty
}
Invoke-Row -Id 'W-23' -Command 'cargo test -p mcao-backend-windows --locked --test console_pipe' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --test console_pipe
}
Invoke-Row -Id 'W-24' -Command 'cargo test -p mcao-backend-windows --locked --test pipe' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --test pipe
}
Invoke-Row -Id 'W-25' -Command 'cargo test -p mcao-backend-windows --locked --lib console_server' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --lib console_server
}
Invoke-Row -Id 'W-26' -Command 'cargo test -p mcao-backend-windows --locked --lib' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-backend-windows --locked --lib
}
Invoke-Row -Id 'W-27' -Command 'cargo test -p mcao-probe --locked --test native' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-probe --locked --test native
}

# ---------- 4.4 probe run with stub harness, bash-free PATH ----------
$probeScript = @'
param([string]$ProbeExe, [string]$OutDir)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$forbidden = 'bash.exe', 'sh.exe', 'wsl.exe'
$found = [System.Collections.Generic.SortedSet[string]]::new()
$kept = @()
$removed = 0
foreach ($dir in ($env:Path -split ';' | Where-Object { $_ })) {
  $hits = @($forbidden | Where-Object { Test-Path -LiteralPath (Join-Path $dir $_) })
  $unixlike = $dir -match '(?i)[\\/](msys64|msys2|cygwin|cygwin64)([\\/]|$)'
  if ($hits.Count -gt 0 -or $unixlike) {
    $removed++
    foreach ($hit in $hits) { [void]$found.Add($hit) }
  } else {
    $kept += $dir
  }
}
$env:Path = $kept -join ';'
$missing = [ordered]@{}
foreach ($name in 'bash', 'sh', 'wsl') {
  $missing[$name] = $null -eq (Get-Command $name -ErrorAction SilentlyContinue)
}
$proof = [ordered]@{
  removed_directories     = $removed
  kept_directories        = $kept.Count
  forbidden_found_on_path = @($found)
  command_missing_after   = $missing
}
$proof | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 (Join-Path $OutDir 'bash-free-path.json')
if ($missing.Values -contains $false) { throw 'a forbidden shell is still on PATH' }
$evidence = Join-Path $OutDir 'probe-evidence.json'
& $ProbeExe --backend native --harness stub --scenario cooperative --evidence-out $evidence
if ($LASTEXITCODE -ne 0) { throw "mcao-probe exited $LASTEXITCODE" }
$expected = [ordered]@{
  spawn       = 'demonstrated'
  capture     = 'unsupported'
  send_text   = 'unsupported'
  interrupt   = 'unsupported'
  agent_state = 'demonstrated'
  reconnect   = 'unsupported'
  cleanup     = 'demonstrated'
}
$records = @(Get-Content -Raw $evidence | ConvertFrom-Json)
if ($records.Count -ne $expected.Count) { throw "expected $($expected.Count) records, got $($records.Count)" }
$i = 0
foreach ($name in $expected.Keys) {
  $record = $records[$i++]
  if ($record.operation -ne $name -or $record.support -ne $expected[$name]) {
    throw "operation $($record.operation): support $($record.support), expected $name $($expected[$name])"
  }
  if ($record.execution -ne 'native' -or $record.harness -ne 'stub' -or $record.backend -ne 'windows-job') {
    throw "operation $($record.operation) is not native windows-job stub evidence"
  }
}
Write-Output 'probe expectations matched'
'@
$probeScriptPath = Join-Path $Results 'bash-free-probe.ps1'
Set-Content -LiteralPath $probeScriptPath -Value $probeScript -Encoding utf8

$probeExe = Join-Path $Clone 'target\x86_64-pc-windows-msvc\debug\mcao-probe.exe'
Invoke-Row -Id 'W-28' -MinTests 0 -Command "& shell -NoProfile -ExecutionPolicy Bypass -File bash-free-probe.ps1 (probe) (results)" -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $probeScriptPath -ProbeExe $probeExe -OutDir $Results
}
$proofPath = Join-Path $Results 'bash-free-path.json'
$proof = Get-Content -LiteralPath $proofPath -Raw | ConvertFrom-Json
$w29pass = ($proof.command_missing_after.bash -eq $true -and $proof.command_missing_after.sh -eq $true -and $proof.command_missing_after.wsl -eq $true)
$w29lines = @(
  "removed_directories=$($proof.removed_directories) kept_directories=$($proof.kept_directories)"
  "forbidden_found_on_path=$($proof.forbidden_found_on_path -join ', ')"
  "bash missing after: $($proof.command_missing_after.bash)"
  "sh   missing after: $($proof.command_missing_after.sh)"
  "wsl  missing after: $($proof.command_missing_after.wsl)"
  "W-29 verdict: $(if ($w29pass) { 'PASS' } else { 'FAIL' })"
)
$w29lines | Out-File -FilePath (Join-Path $Results 'logs\W-29.log') -Encoding utf8
"$($w29lines | Select-Object -Last 1)"

# ---------- 4.5 platform leakage guard ----------
Invoke-Row -Id 'W-30' -Command 'cargo test -p mcao-probe --locked --test platform_leakage' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-probe --locked --test platform_leakage
}

# ---------- 4.6 CLI offline behaviour and FM_HOME rules ----------
$mcao = Join-Path $Clone 'target\debug\mcao.exe'
$shell = (Get-Process -Id $PID).Path
$preflightScript = @'
param([string]$Mcao, [string]$PathValue, [string]$FmHome, [string]$OneDriveVar, [string]$OneDriveValue, [string]$UserProfile, [switch]$ExpectGitMissing)
$env:Path = $PathValue
if ($ExpectGitMissing -and (Get-Command git -ErrorAction SilentlyContinue)) { Write-Output 'git still found on PATH; stop'; exit 9 }
Remove-Item Env:FM_HOME -ErrorAction SilentlyContinue
foreach ($name in 'OneDrive', 'OneDriveCommercial', 'OneDriveConsumer') { Remove-Item -Path ("Env:" + $name) -ErrorAction SilentlyContinue }
if ($FmHome -ne '') { $env:FM_HOME = $FmHome }
if ($OneDriveVar -ne '') { Set-Item -Path ("Env:" + $OneDriveVar) -Value $OneDriveValue }
if ($UserProfile -ne '') { $env:USERPROFILE = $UserProfile }
& $Mcao preflight
exit $LASTEXITCODE
'@
$preflightPath = Join-Path $Results 'preflight-child.ps1'
Set-Content -LiteralPath $preflightPath -Value $preflightScript -Encoding utf8

# real gh is present on this laptop; no stub needed for any preflight row.
Invoke-Row -Id 'W-31' -MinTests 0 -Command 'mcao.exe --version' -Action { & $mcao --version }
Invoke-Row -Id 'W-32' -MinTests 0 -Command 'mcao.exe --help' -Action { & $mcao --help }
Invoke-Row -Id 'W-33' -MinTests 0 -Command 'mcao preflight, Git and real gh on PATH, FM_HOME absent' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $env:Path -FmHome '' -OneDriveVar '' -OneDriveValue '' -UserProfile ''
}
Invoke-Row -Id 'W-34' -MinTests 0 -Command 'mcao preflight, Git missing (System32 PATH child, ExpectGitMissing)' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue "$env:SystemRoot\System32" -ExpectGitMissing
}

$fmHome = Join-Path $env:TEMP 'mcao winverify 有人 ÄÖ'
New-Item -ItemType Directory -Force -Path $fmHome | Out-Null
Invoke-Row -Id 'W-35' -MinTests 0 -Command 'mcao preflight, spaces and non-ASCII FM_HOME' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $env:Path -FmHome $fmHome -OneDriveVar '' -OneDriveValue '' -UserProfile ''
}
Remove-Item -LiteralPath $fmHome -Recurse -Force -ErrorAction SilentlyContinue

$uncShare = '\\localhost\c$'
if (Test-Path -LiteralPath $uncShare) {
  $uncHome = '\\localhost\c$\mcao-winverify-fmhome'
  Invoke-Row -Id 'W-36' -MinTests 0 -Command 'mcao preflight, UNC FM_HOME' -Action {
    & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $env:Path -FmHome $uncHome -OneDriveVar '' -OneDriveValue '' -UserProfile ''
  }
  Remove-Item -LiteralPath $uncHome -Recurse -Force -ErrorAction SilentlyContinue
} else {
  "W-36 SKIPPED: no accessible UNC share on this laptop (Test-Path '\\localhost\c$' = false)"
}

$odRoot = Join-Path $env:TEMP 'OneDrive-winverify'
New-Item -ItemType Directory -Force -Path $odRoot | Out-Null
$odHome = Join-Path $odRoot 'home'
New-Item -ItemType Directory -Force -Path $odHome | Out-Null
foreach ($varName in 'OneDrive', 'OneDriveCommercial', 'OneDriveConsumer') {
  Invoke-Row -Id "W-37-$varName" -MinTests 0 -Command "mcao preflight, OneDrive root via $varName" -Action {
    & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $env:Path -FmHome $odHome -OneDriveVar $varName -OneDriveValue $odRoot -UserProfile ''
  }
}

$profileRoot = Join-Path $env:TEMP 'mcao-winverify-profile'
New-Item -ItemType Directory -Force -Path (Join-Path $profileRoot 'OneDrive - winverify\home') | Out-Null
Invoke-Row -Id 'W-37b' -MinTests 0 -Command 'mcao preflight, profile sync folder warning only' -Action {
  & $shell -NoProfile -ExecutionPolicy Bypass -File $preflightPath -Mcao $mcao -PathValue $env:Path -FmHome (Join-Path $profileRoot 'OneDrive - winverify\home') -OneDriveVar '' -OneDriveValue '' -UserProfile $profileRoot
}

Invoke-Row -Id 'W-38' -Command 'cargo test -p mcao-core --locked --test preflight the_default_home' -Action {
  Set-Location -LiteralPath $Clone; cargo test -p mcao-core --locked --test preflight the_default_home
}

# W-39 is a reference to W-13; no separate run (recorded in SUMMARY.md).

Invoke-Row -Id 'CLOSE' -MinTests 0 -Command 'after-row git status and cleanup' -Action {
  Set-Location -LiteralPath $Clone
  "git status --porcelain after last row:"
  git status --porcelain
  Remove-Item -LiteralPath (Join-Path $env:TEMP 'mcao winverify 有人 ÄÖ') -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path $env:TEMP 'OneDrive-winverify') -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path $env:TEMP 'mcao-winverify-profile') -Recurse -Force -ErrorAction SilentlyContinue
}

# ---------- section 8 redaction ----------
Get-ChildItem -LiteralPath (Join-Path $Results 'logs') -File | ForEach-Object {
  $text = Get-Content -LiteralPath $_.FullName -Raw
  $text = $text.Replace($env:USERNAME, '<user>').Replace($env:COMPUTERNAME, '<host>')
  Set-Content -LiteralPath $_.FullName -Value $text -Encoding utf8
}
$rows = Get-Content -LiteralPath $RowsTsv -Raw
$rows = $rows.Replace($env:USERNAME, '<user>').Replace($env:COMPUTERNAME, '<host>')
Set-Content -LiteralPath $RowsTsv -Value $rows -Encoding utf8

'DRIVER-DONE'
