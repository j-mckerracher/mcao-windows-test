param([string]$Mcao, [string]$PathValue, [string]$FmHome, [string]$OneDriveVar, [string]$OneDriveValue, [string]$UserProfile, [switch]$ExpectGitMissing)
$env:Path = $PathValue
if ($ExpectGitMissing -and (Get-Command git -ErrorAction SilentlyContinue)) { Write-Output 'git still found on PATH; stop'; exit 9 }
Remove-Item Env:FM_HOME -ErrorAction SilentlyContinue
foreach ($name in 'OneDrive', 'OneDriveCommercial', 'OneDriveConsumer') { Remove-Item -Path ("Env:" + $name) -ErrorAction SilentlyContinue }
if ($FmHome -ne '') { $env:FM_HOME = $FmHome }
if ($OneDriveVar -ne '') { Set-Item -Path ("Env:" + $OneDriveVar) -Value $OneDriveValue }
if ($UserProfile -ne '') { $env:USERPROFILE = $UserProfile }
& $Mcao preflight
exit $LASTEXITCODE
