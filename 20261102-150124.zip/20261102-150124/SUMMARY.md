# Native Windows verification report

Companion packet: `windows-native-verification.md` (copied in this folder as `packet-copy.md`). All user names redacted as `<user>`, machine name as `<host>`.

## 1. Run identity

- Run ID: `20261102-150124`
- Branch tested (`BRANCH`): `windows-verification`
- Pinned base checked out (must equal `1086480770dc606b1a6fdc2832aa36a62e8f79f4`): `b324a8145dc218c5de3d4e593f89f0cfb39d79bc` — **not** the pinned base above; the packet states the earlier pinned base is not present in this repository copy, so the branch tip as cloned is the tested commit.
- Commit tested: `b324a8145dc218c5de3d4e593f89f0cfb39d79bc`
- `git status --porcelain` on the clone after the pinned checkout: `<empty>`
- `git status --porcelain` on the clone after the last row: `<empty>`
- Clone path (user name redacted): `C:\Users\<user>\AppData\Local\mcao-winverify\src`
- Results folder path (user name redacted): `C:\Users\<user>\AppData\Local\mcao-winverify\20261102-150124`
- Start and end time (local): 2026-11-02 15:03:43 / 2026-11-02 15:11:35
- Operator who ran the packet: omp coding agent (firstmate harness) on the managed Windows 11 laptop, at owner request
- Shell used for every row: `pwsh 7.4.14 (Core)` (`pwsh.exe`; driver and child shells all pwsh)
- `gh` on PATH for the preflight rows: `real gh` (`C:\Program Files\GitHub CLI\gh.exe`); no stub needed

## 2. Environment block

| Field | Value |
| --- | --- |
| Windows version (`VersionString`) | `Microsoft Windows NT 10.0.26200.0` |
| Windows edition (`Caption`) | `Microsoft Windows 11 Education` |
| Windows build (`BuildNumber`) | `26200` |
| Architecture (`PROCESSOR_ARCHITECTURE`) | `AMD64` |
| PowerShell version and edition | `7.4.14 Core` |
| git | `git version 2.46.2.windows.1` |
| rustc (`rustc -Vv`, host line only) | `rustc 1.95.0 (59807616e 2026-04-14)`, `host: x86_64-pc-windows-msvc` |
| cargo (`cargo -V`) | `cargo 1.95.0 (f2d3ce0bd 2026-03-21)` |
| Active toolchain (`rustup show active-toolchain`) | `1.95.0-x86_64-pc-windows-msvc (overridden by rust-toolchain.toml in the clone)` |
| Rust targets installed (`rustup target list --installed`) | `aarch64-apple-darwin`, `x86_64-pc-windows-msvc`, `x86_64-unknown-linux-gnu` |
| MSVC Build Tools found (section 2.1 of the packet) | `yes, path redacted to <vs>` (vswhere found `Microsoft.VisualStudio.Component.VC.Tools.x86.x64`) |
| `link.exe` outside the system folder (section 2.1) | `no` |
| Proxy in use (value never printed) | `no` (direct downloads to GitHub and rustup targets succeeded) |
| OneDrive-redirected profile | `yes` (folders `OneDrive` and `OneDrive - purdue.edu` exist under USERPROFILE; the `OneDrive*` env variables were empty in the shells used; FM_HOME/results live under `%LOCALAPPDATA%`, unaffected). Check used: directory listing of USERPROFILE plus `Get-CimInstance`. |
| Running elevated (administrator) | `no` |
| Long paths: `core.longpaths` and `LongPathsEnabled` (read back) | `core.longpaths: not set / LongPathsEnabled: 1` |
| Authenticode status of `rustup-init.exe` (information only) | `not run — rustup was already installed on this laptop; no rustup-init.exe was downloaded or executed (see anomalies)` |
| rustup-init SHA-256 matched the published value | `not run — rustup was already installed (see anomalies)` |
| Line endings (section 2.4): `crlf-text` and `lf-text` counts | `crlf-text=0 lf-text=1577` |

## 3. Summary table

One row per matrix row in section 4 of the packet. `Test results` below quotes the log's `running`/`test result` lines. `W-36` executed this run because an admin share was reachable; it is a SPEC-ONLY row with no expected result.

| ID | Command | Expected tests | Tests run | Exit code | Duration (s) | Status | Evidence file | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| W-01 | `rustup show active-toolchain`; `rustc -Vv` | n/a | n/a | `0` | `1` | PASS | `logs/W-01.log` | Active `1.95.0-x86_64-pc-windows-msvc`; `host: x86_64-pc-windows-msvc` |
| W-02 | `cargo build -p mcao-cli --locked --bin mcao` | n/a | n/a | `0` | `102` | PASS | `logs/W-02.log` | `target\debug\mcao.exe` produced (verified after run) |
| W-03 | `cargo build -p mcao-probe --locked --target x86_64-pc-windows-msvc` | n/a | n/a | `0` | `55` | PASS | `logs/W-03.log` | `target\x86_64-pc-windows-msvc\debug\mcao-probe.exe` produced |
| W-04 | `cargo check --workspace --locked --target x86_64-pc-windows-msvc` | n/a | n/a | `0` | `27` | PASS | `logs/W-04.log` | |
| W-05 | `cargo clippy --workspace --all-targets --locked -- -D warnings` | n/a | n/a | `101` | `25` | FAIL | `logs/W-05.log` | Clippy `-D warnings` fails in `mcao-cli` test binaries; exact lines in anomalies |
| W-06 | `cargo test --workspace --locked` | at least 1 per binary | `10` binaries (5 with 0 tests, 4 passed binaries, 1 FAILED) | `101` | `78` | FAIL | `logs/W-06.log`, `W-06-grep.txt` | Stopped at first failing binary `mcao-backend-windows --test interrupt` (same failure as W-21); crates after it in the workspace were not run in this row. 5 doc-test binaries `running 0 tests` (`test result: ok`). |
| W-07 | `cargo test -p mcao-core --locked --test error a_task_id_refused_at_creation` | 1 | `1` | `0` | `31` | PASS | `logs/W-07.log` | `test result: ok. 1 passed` |
| W-08 | `cargo test -p mcao-core --locked --test state_encoding` | at least 1 | `46` | `0` | `2` | PASS | `logs/W-08.log` | 46 passed (host printout was 48; Windows run has 46) |
| W-09 | `cargo test -p mcao-core --locked --test home` | at least 1 | `22` | `0` | `2` | PASS | `logs/W-09.log` | Includes the `cfg(windows)` case-insensitive test (22 total) |
| W-10 | `cargo test -p mcao-core --locked --test windows_registry` | at least 1 | `3` | `0` | `2` | PASS | `logs/W-10.log` | HKCU throwaway subkey only, not elevated |
| W-11 | `cargo test -p mcao-core --locked --test preflight` | at least 1 | `36` | `0` | `2` | PASS | `logs/W-11.log` | OneDrive and device-namespace cases included |
| W-12 | `cargo test -p mcao-core --locked --lib preflight` | at least 1 | `13` | `0` | `12` | PASS | `logs/W-12.log` | |
| W-13 | `cargo test -p mcao-cli --locked --test preflight` | at least 1 | `13` | `0` | `5` | PASS | `logs/W-13.log` | Git-missing exit 3, non-ASCII FM_HOME, overlong home (`cfg(windows)`) included |
| W-14 | `cargo test -p mcao-cli --locked --test cli` | at least 1 | `8` | `0` | `2` | PASS | `logs/W-14.log` | |
| W-15 | `cargo test -p mcao-cli --locked --test toolchain` | at least 1 | `8` | `0` | `3` | PASS | `logs/W-15.log` | |
| W-16 | `cargo test -p mcao-cli --locked --test herdr_lab_viewer` | at least 1 | `4` | `0` | `2` | PASS | `logs/W-16.log` | `lab_viewer_is_unsupported_on_windows` passed |
| W-17 | `cargo test -p mcao-cli --locked --test audit_validate --test audit_activity_map` | at least 1 per binary | `8` + `6` | `101` | `3` | FAIL | `logs/W-17.log` | `audit_activity_map` ok; `audit_validate` 5 passed 1 FAILED (`a_rejection_without_a_state_directory_is_not_printed`). No `ok`/`zone` mentions beyond that: the `#[cfg(unix)] zone_bearing` module was absent as documented. |
| W-18 | `cargo check --workspace --locked --target x86_64-unknown-linux-gnu`, then `--target aarch64-apple-darwin` | n/a | n/a | `0` / `0` | `9` / `10` | PASS | `logs/W-18-linux.log`, `logs/W-18-darwin.log` | |
| W-19 | `cargo test -p mcao-backend-windows --locked --test job` | at least 1 | `10` (`running` lines `7+1+1+1`) | `0` | `13` | PASS | `logs/W-19.log` | Job binary: `test result: ok. 4 passed; 3 ignored`. Plus three re-exec stub binaries printing `running 1 test` (their owning tests started them). |
| W-20 | `cargo test -p mcao-backend-windows --locked --test backend` | at least 1 | `14` | `0` | `3` | PASS | `logs/W-20.log` | `10 passed; 4 ignored` |
| W-21 | `cargo test -p mcao-backend-windows --locked --test interrupt` | at least 1 | `23` | `101` | `13` | FAIL | `logs/W-21.log` | `15 passed; 7 ignored; 1 FAILED`; failure and recorded error in anomalies |
| W-22 | `cargo test -p mcao-backend-windows --locked --test conpty` | at least 1 | `25` | `0` | `3` | PASS | `logs/W-22.log` | `20 passed; 5 ignored`; run under pwsh 7 with a console host (agent-spawned), not elevated |
| W-23 | `cargo test -p mcao-backend-windows --locked --test console_pipe` | at least 1 | `7` | `0` | `13` | PASS | `logs/W-23.log` | |
| W-24 | `cargo test -p mcao-backend-windows --locked --test pipe` | at least 1 | `3` | `0` | `2` | PASS | `logs/W-24.log` | |
| W-25 | `cargo test -p mcao-backend-windows --locked --lib console_server` | 13 (host list) | `13` | `0` | `6` | PASS | `logs/W-25.log` | All 13 |
| W-26 | `cargo test -p mcao-backend-windows --locked --lib` | 18 (host list) | `88` | `0` | `2` | PASS | `logs/W-26.log` | `87 passed; 1 ignored` — the Windows lib binary has 88 tests, far above the host's 18 |
| W-27 | `cargo test -p mcao-probe --locked --test native` | at least 1 | `6` | `0` | `6` | PASS | `logs/W-27.log` | |
| W-28 | probe via `bash-free-probe.ps1` (child shell, bash-free PATH): `mcao-probe.exe --backend native --harness stub --scenario cooperative` | not a Cargo test | n/a | `0` | `3` | PASS | `logs/W-28.log`, `probe-evidence.json`, `bash-free-path.json` | Output `probe expectations matched`; seven records in the expected order: spawn demonstrated, capture unsupported, send_text unsupported, interrupt unsupported, agent_state demonstrated, reconnect unsupported, cleanup demonstrated (all native/windows-job/stub) |
| W-29 | Bash-free PATH counts from `bash-free-path.json` (`bash`, `sh`, `wsl`) | not a Cargo test | n/a | `n/a` | `<1>` | PASS | `bash-free-path.json` | `removed_directories=5 kept_directories=49`; `forbidden_found_on_path=bash.exe, wsl.exe` (no paths recorded); all three commands missing after: true |
| W-30 | `cargo test -p mcao-probe --locked --test platform_leakage` | 12 (host list) | `12` | `0` | `23` | PASS | `logs/W-30.log` | 12 passed |
| W-31 | `mcao.exe --version` | not a Cargo test | n/a | `0` | `1` | PASS | `logs/W-31.log` | |
| W-32 | `mcao.exe --help` | not a Cargo test | n/a | `0` | `0` | PASS | `logs/W-32.log` | |
| W-33 | `mcao.exe preflight` (Git and real gh on PATH) | not a Cargo test | n/a | `0` | `1` | PASS | `logs/W-33.log` | `Git: ok`, `Gh: ok`, `Preflight: all checks passed` |
| W-34 | `mcao.exe preflight` with Git removed from PATH (child, `-ExpectGitMissing`) | not a Cargo test | n/a | `3` | `1` | PASS | `logs/W-34.log` | `Preflight check failed: Git: MISSING (not found on PATH); install Git from https://git-scm.com and open a new terminal`; no `Gh:` line |
| W-35 | `mcao.exe preflight` with spaces and non-ASCII FM_HOME | not a Cargo test | n/a | `0` | `1` | PASS | `logs/W-35.log` | `FM_HOME path length: ok (C:\Users\<user>\AppData\Local\Temp\mcao winverify 有人 ÄÖ)` — path unchanged; used real gh; folder removed afterwards |
| W-36 | `mcao.exe preflight` with UNC FM_HOME | not a Cargo test | n/a | `0` | `1` | PASS | `logs/W-36.log` | SPEC-ONLY, no expected result. Executed because `\\localhost\c$` was reachable: `FM_HOME path length: ok (\\localhost\c$\mcao-winverify-fmhome)`, `FM_HOME OneDrive: ok (...)`, `Preflight: all checks passed`. Home folder removed afterwards. Owner ruling on UNC homes is open. |
| W-37 | `mcao.exe preflight` with OneDrive root, for `OneDrive`, `OneDriveCommercial`, `OneDriveConsumer` | not a Cargo test | n/a | `3` / `3` / `3` | `1` | PASS | `logs/W-37-OneDrive.log`, `logs/W-37-OneDriveCommercial.log`, `logs/W-37-OneDriveConsumer.log` | Exit 3 each; `Preflight check failed: FM_HOME OneDrive: operational home ... is under the OneDrive folder ... named by <var>; set FM_HOME to %LOCALAPPDATA%\mcao\home or another folder that OneDrive does not sync` |
| W-37b | `mcao.exe preflight` with a profile sync folder (warning only) | not a Cargo test | n/a | `0` | `1` | PASS | `logs/W-37b.log` | `FM_HOME OneDrive: warning:` present; `a sync folder beneath USERPROFILE`; exit 0 with `Preflight: all checks passed` |
| W-38 | `cargo test -p mcao-core --locked --test preflight the_default_home` | 2 | `2` | `0` | `3` | PASS | `logs/W-38.log` | `test result: ok. 2 passed` |
| W-39 | Reference only: W-13 covers the overlong-home test | n/a | n/a | `n/a` | `n/a` | SKIPPED | none | Reference row by packet definition; no separate run. The `cfg(windows)` overlong-home test itself ran inside W-13. |
| W-40 | `cargo test -p mcao-core --locked --test state_encoding a_new_task_id_with_uppercase` | 1 | `1` | `0` | `0` | PASS | `logs/W-40.log` | `test result: ok. 1 passed` |

## 4. Acceptance coverage (for the owner)

| Work item | Criterion | Rows | Result | Reason if not fully covered |
| --- | --- | --- | --- | --- |
| DPES-752 | AC1 (partial) | W-02, W-03, W-27, W-28, W-29 | covered | Every named row PASS; the packet defines the criterion as partial (no WS is checked beyond W-29's bash-free PATH plus probe and backend evidence) |
| DPES-752 | AC4 (partial) | W-04, W-18 | covered | All three pinned targets checked on this host |
| DPES-754 | AC2 | W-34 | covered | Exit 3 with the documented Git remedy, no `Gh:` line |
| DPES-754 | AC3 | W-35 | covered | Path with spaces and CJK/umlauts printed unchanged, exit 0, with real `gh` on PATH |
| DPES-754 | AC5 | W-31, W-32, W-38 | covered | `--version`, `--help`, and the two default-home unit tests all pass offline |
| DPES-755 | AC1, AC2, AC3 (partial) | W-19, W-20, W-21 | partial | W-19/W-20 PASS (Job Object cleanup, backend launch/state). W-21 FAIL: the escalation assertion saw state `Exited` where it expected `TerminatedJob` (`interrupt.rs:523`) — recorded as evidence, per the packet this maps to the DPES-752-AC3 Unsupported/Unresolved escalation case rather than a harness bug |
| DPES-755 | AC5 | W-18 | covered | Both cross targets compile (`cargo check`; no link) |
| DPES-759 | AC1, AC2, AC4 (partial), AC5 | W-04, W-05, W-06, W-29 | partial | W-04 PASS and W-29 PASS, but the format/lint gate fails natively: W-05 clippy `-D warnings` fails in `mcao-cli` test binaries and W-06 workspace tests stop on the interrupt failure |
| DPES-883 | AC1-AC6, AC7-AC9, AC22 (partial) | W-23 to W-26 | covered | All four rows PASS at the pipe/ring-buffer/codec/ACL unit and frame level |
| DPES-885 | AC1-AC9 (partial, frame level) | W-22, W-23 | covered | Frame-level terminal and slot/input paths pass; live keystroke/resize rows are out of scope by design |
| DPES-889 | AC1, AC2, AC3, AC5, AC6, AC7, AC10 (partial) | W-07, W-08, W-09, W-40 | covered | Verbatim write, opaque read, version stamping, Windows device names, uppercase refusal at creation, legacy read, case-insensitive home matching all pass |
| DPES-892 | AC3 (registry, partial), AC4, AC5, AC8 (partial) | W-10, W-11, W-13, W-37, W-37b, W-38 | covered | Registry test passes non-elevated; OneDrive root exits 3 for all three variables; profile sync folder warns with exit 0; default home unit tests pass |

Not covered by this packet, by design: DPES-752 AC2, AC3 (Unresolved: W-21 escalation evidence), AC5 (owner decisions); DPES-754 AC1 and AC4 second half (managed install and clean-host proof); DPES-755 AC4 (reconnect); DPES-883 AC10-AC21 live attach and `mcao peek`; DPES-885 live keystrokes, resize, and the Windows steer end-to-end test; DPES-889 AC11 (Unix side); DPES-892 AC1, AC2, AC6, AC7, AC9. Any claim beyond the coverage above is not supported by this run.

## 5. Full logs

All row logs are under `logs\`, one file per nearly every row (W-39 is a reference row with no log). `logs\driver.log` holds the row driver's own summary lines (extra file, noted in anomalies).

- Rows run: `39` (all rows W-01 to W-40 except W-39)
- Rows PASS: `35`
- Rows FAIL (including FAIL (vacuous)): `4`
- Rows KNOWN-FAILURE: `0`
- Rows SKIPPED: `1` (W-39)

Skipped rows and reasons:

- `W-39: reference only — the packet defines no separate run; the overlong-home test it references (`preflight_exits_three_naming_the_path_length_check_for_an_overlong_home`, `cfg(windows)`) executed inside W-13`

Note: W-18 is one packet row run as two commands (`logs/W-18-linux.log` and `logs/W-18-darwin.log`); W-37 is one packet row run as three child-shell runs (one log per OneDrive variable). W-36 was executable this run (no skip needed).

## 6. Anomalies and questions

- `environment`: `rustup`, `rustc` (1.96.0 stable default) and `cargo` were already installed on this laptop, and `1.95.0-x86_64-pc-windows-msvc` was already present, so section 2.2 (official `rustup-init.exe` download, Authenticode and SHA-256 checks) was not executed. The pinned toolchain was confirmed via `rustup show` inside the clone. The two `rustup-init` fields in the environment block read `not run`. — What was done: recorded as not run; no installer was downloaded or executed.
- `setup`: `C:\mcao-winverify` could not be created (`Access is denied`) on this non-admin session, so the clone and every artifact from this packet live under `%LOCALAPPDATA%\mcao-winverify\` (an allowed folder per section 8) instead of `C:\mcao-winverify\src`. — What was done: cloned to `%LOCALAPPDATA%\mcao-winverify\src`; no admin elevation attempted.
- `run identity`: the template's pinned base `1086480770dc606b1a6fdc2832aa36a62e8f79f4` is not reachable in this copy (the packet says so); the tested commit is the branch tip `b324a8145dc218c5de3d4e593f89f0cfb39d79bc`.
- `W-05` (FAIL): clippy with `-D warnings` fails in `mcao-cli` test binaries (exit 101):
  - `error: unused import: \`std::io::Write\`` (test `audit_validate`)
  - `error: unused import: \`Stdio\`` (test `audit_validate`)
  - `error: function \`assert_result\` is never used` (test `audit_validate`)
  - `error: unused import: \`Child\`` (test `hook_host_mirror`)
  - `error: could not compile \`mcao-cli\` (test "audit_validate") due to 3 previous errors`
  - `error: could not compile \`mcao-cli\` (test "hook_host_mirror") due to 1 previous error`
  - What was done: captured the log; no source or CI file was edited.
- `W-06` (FAIL): `cargo test --workspace --locked` stops after `mcao-backend-windows --test interrupt` fails (see W-21); binaries earlier in the workspace order passed, five doc-test binaries reported `running 0 tests` (`test result: ok`), and crates later in the workspace order were not executed in this row (their per-crate rows W-07 to W-17 and W-27/W-30 cover them). Without `-D warnings`, the same unused items from W-05 compile as plain warnings in `audit_activity_map`, `hook_host_mirror`, `hook_onedrive_guard`, and `audit_validate`.
- `W-17` (FAIL): `a_rejection_without_a_state_directory_is_not_printed` panicked at `crates\mcao-cli\tests\audit_validate.rs:298`: `assertion failed: String::from_utf8_lossy(&output.stderr).contains("FM_HOME or FM_STATE_OVERRIDE")` — the child's stderr did not contain that text. `audit_activity_map` (6 tests) passed.
- `W-21` (FAIL): `escalation_sends_a_second_ctrl_c_then_terminates_the_tree_at_the_wait` panicked at `crates\mcao-backend-windows\tests\interrupt.rs:523`: `assertion \`left == right\` failed; left: Exited; right: TerminatedJob` — i.e. the recorded state was `Exited`, not the expected `TerminatedJob`, after the stop-or-kill ladder. `15 passed; 7 ignored; 1 FAILED`. Per the packet this is recorded as the DPES-752-AC3 escalation evidence, not treated as a harness bug.
- `W-19`: besides the `job` binary (`4 passed; 3 ignored`), three small re-exec stub binaries each printed `running 1 test` (kept as-is; the packet names these stub mechanisms for job.rs/interrupt.rs).
- `W-36`: the admin share `\\localhost\c$` was reachable from this session, so the normally-unlikely UNC row executed. It created `\\localhost\c$\mcao-winverify-fmhome` (on the system drive root), ran preflight against it, and removed it afterwards. This touched one folder outside the packet's named temp folders; noting for owner awareness. Result: preflight passes a UNC home (`FM_HOME path length: ok`, `FM_HOME OneDrive: ok`).
- `results folder extras`: `driver.ps1`, `logs\driver.log`, `preflight-child.ps1`, `bash-free-probe.ps1` (the packet instructs writing the last two), `W-06-grep.txt` (the packet's W-06 grep capture), `env-versions.ps1`, `eol-check.ps1` (setup helpers), and `probe-evidence.json.redaction.json` (written by `mcao-probe` itself).
- `environment (informational)`: the Windows profile carries OneDrive roots (`OneDrive`, `OneDrive - purdue.edu`) although the `OneDrive*` variables were empty in the shells used.
- No other anomalies: no proxy or download block, no credential prompts, no timeouts, no CRLF text files, no modified tracked files at any point (`git status --porcelain` empty before and after), no elevated step taken.
- Questions for the owner:
  - `W-21`/`W-06`: the interrupt escalation record is `Exited` vs the expected `TerminatedJob` — is this the DPES-752-AC3 Unresolved case as anticipated, and is the expected owner ruling "child gone after ladder passes" satisfied only by the ladder, or must this test name match a documented known-failure list?
  - `W-36`: preflight currently accepts a UNC home (exit 0); the packet says no expected result until an owner ruling — please rule.

## 7. Packaging

- Zip path (full, user name redacted): `C:\Users\<user>\AppData\Local\mcao-winverify\20261102-150124.zip`
- Zip size: `75607 bytes`
- The zip was created with `Compress-Archive` from the results folder only: `yes`
- No file was copied outside the results folder, and nothing was uploaded: `yes` (one exception recorded in anomalies: the W-36 UNC home folder, created and deleted on the system drive root through the local admin share)
- No commit, push, pull request, or Jira action was taken: `yes`
- The clone has no modified tracked files after the run (`git status --porcelain`): `<empty>`
