
"VersionString: " + [System.Environment]::OSVersion.VersionString
"Caption: " + (Get-CimInstance Win32_OperatingSystem).Caption
"BuildNumber: " + (Get-CimInstance Win32_OperatingSystem).BuildNumber
"Arch: " + $env:PROCESSOR_ARCHITECTURE
"PSVersion: " + $PSVersionTable.PSVersion.ToString() + " " + $PSVersionTable.PSEdition
git --version
rustc -Vv
cargo -V
rustup show active-toolchain
"Userprofile: $env:USERPROFILE"
"OneDrive dirs under profile: " + (@(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'OneDrive*' }).Count)
"ProfileDotOneDrive env OneDriveCommercial: [$env:OneDriveCommercial]"
"Elevated: " + (([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
